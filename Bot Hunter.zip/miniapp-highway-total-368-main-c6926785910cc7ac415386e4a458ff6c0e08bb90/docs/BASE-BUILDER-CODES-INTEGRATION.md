# Base Builder Codes Integration Guide

## 🎯 Overview

Bot Hunter is fully integrated with **Base Builder Codes** (ERC-8021) for transparent transaction attribution and reward distribution. This guide covers the complete integration setup.

## ✅ What's Implemented

### Core Infrastructure
- ✅ **ERC-8021 encoding/decoding** utilities
- ✅ **Wagmi configuration** for Base mainnet & testnet
- ✅ **Web3Provider** with React Query
- ✅ **Attribution hooks** using `wallet_sendCalls` (ERC-5792)
- ✅ **Multi-entity attribution** (app + wallet)
- ✅ **Legacy support** for `writeContract` (EOA only)
- ✅ **Security validations** and test suite

### Files Created
```
src/
├── lib/
│   ├── wagmi-config.ts              # Web3 configuration
│   ├── erc8021.ts                   # ERC-8021 core utilities
│   ├── attribution.ts               # Bot Hunter attribution helpers
│   └── legacy-attribution.ts        # Legacy EOA support
├── hooks/
│   ├── useAttributedTransaction.ts  # Main attribution hook
│   └── useMultiEntityAttribution.ts # Multi-entity hook
├── components/
│   ├── Web3Provider.tsx             # Wagmi + React Query wrapper
│   └── ClaimRewardButton.tsx        # Example usage
├── config/
│   └── erc8021.ts                   # Centralized configuration
└── types/
    └── erc8021.ts                   # TypeScript interfaces
```

## 📋 Setup Checklist

### Step 1: Register on base.dev ⚠️ REQUIRED

1. Visit [https://base.dev](https://base.dev)
2. Register Bot Hunter app with:
   - **App Name:** Bot Hunter
   - **Wallet:** `0x29536D0bc1004ab274c4F0F59734Ad74D4559b7B`
   - **URL:** Your production URL

3. You'll receive:
   - **Builder Code** (e.g., `k3p9da`)
   - **base:app_id** (e.g., `68f40c278c4fe3f562003d93`)

### Step 2: Update Configuration

#### Update Builder Code
**File:** `src/config/erc8021.ts` (line 18)

```typescript
// BEFORE (placeholder)
code: 'bothunter',

// AFTER (actual Builder Code from base.dev)
code: 'bc_9b19fklw', // ✅ Real Builder Code configured
```

#### Add base:app_id to Metadata
**File:** `src/app/layout.tsx` (line 50-52)

```typescript
other: { 
  "fc:frame": JSON.stringify({...}),
  "base:app_id": "68f40c278c4fe3f562003d93" // ← Your app_id here
}
```

### Step 3: Dependencies

All required dependencies are already installed:
- ✅ `wagmi@^2.19.5`
- ✅ `viem@^2.41.2`
- ✅ `ox@^0.1.8`
- ✅ `@tanstack/react-query@^5.90.12`
- ✅ `@wagmi/core@^2.22.1`

## 🚀 Usage Examples

### Basic Transaction with Attribution

```typescript
import { useAttributedTransaction } from '@/hooks/useAttributedTransaction';
import { encodeFunctionData } from 'viem';

function MyComponent() {
  const { sendWithAttribution, isPending } = useAttributedTransaction();

  async function handleTransaction() {
    const calldata = encodeFunctionData({
      abi: CONTRACT_ABI,
      functionName: 'mint',
      args: [userAddress, tokenId],
    });

    // Attribution is automatically added!
    await sendWithAttribution([{
      to: '0xContractAddress',
      data: calldata,
      value: 0n
    }]);
  }

  return (
    <button onClick={handleTransaction} disabled={isPending}>
      {isPending ? 'Processing...' : 'Mint NFT'}
    </button>
  );
}
```

### Multi-Entity Attribution (App + Wallet)

```typescript
import { useMultiEntityAttribution } from '@/hooks/useMultiEntityAttribution';

function MyComponent() {
  // Attribute to both Bot Hunter + Coinbase Wallet
  const { sendWithMultiAttribution } = useMultiEntityAttribution('coinbase');

  async function handleTransaction() {
    await sendWithMultiAttribution([{
      to: '0xContractAddress',
      data: calldata,
      value: 0n
    }]);
  }

  return <button onClick={handleTransaction}>Send Transaction</button>;
}
```

### Legacy EOA Support (writeContract)

For older codebases still using `writeContract`:

```typescript
import { prepareLegacyTransaction } from '@/lib/legacy-attribution';
import { writeContract } from 'wagmi/actions';

// Manually encode with attribution
const dataWithAttribution = prepareLegacyTransaction(
  CONTRACT_ABI,
  'mint',
  [userAddress, tokenId]
);

// Use with writeContract
await writeContract({
  address: contractAddress,
  abi: CONTRACT_ABI,
  functionName: 'mint',
  args: [userAddress, tokenId],
  data: dataWithAttribution // ← Attribution included
});
```

## 🔍 How It Works

### ERC-5792 wallet_sendCalls (Recommended)

The modern approach uses the `dataSuffix` capability:

1. **Generate suffix** with your Builder Code
2. **Pass via capability** to `wallet_sendCalls`
3. **Wallet appends** to transaction calldata
4. **Works for both** EOA and Smart Accounts (ERC-4337)

```typescript
const dataSuffix = Attribution.toDataSuffix({
  codes: ['bc_9b19fklw'] // Bot Hunter Builder Code
});

await sendCalls({
  calls: [...],
  capabilities: {
    dataSuffix: { value: dataSuffix }
  }
});
```

### Attribution Suffix Format

```
{txData}{codes}{codesLength}{schemaId}{ercSuffix}
```

**Example:**
```
0xOriginalData + "bc_9b19fklw" + 0x0B + 0x00 + 0x80218021802180218021802180218021
```

## 📊 Verification

### 1. Check Transaction on Basescan

After sending a transaction:
1. Open transaction on [Basescan](https://basescan.org)
2. View **Input Data**
3. Verify suffix ends with `...80218021802180218021802180218021`

### 2. View Analytics on base.dev

1. Log in to [base.dev](https://base.dev)
2. Navigate to your app dashboard
3. View transaction attribution stats
4. Monitor reward distribution

### 3. Query Code Registry

```typescript
import { BOT_HUNTER_CONFIG } from '@/config/erc8021';

// Your payout address
console.log(BOT_HUNTER_CONFIG.payoutAddress);
// 0x29536D0bc1004ab274c4F0F59734Ad74D4559b7B
```

## 🛡️ Security Features

All transactions include:
- ✅ **Parsing validation** - Prevents malformed suffixes
- ✅ **Code validation** - Ensures 7-bit ASCII compliance
- ✅ **Buffer overflow protection** - Safe parsing limits
- ✅ **Privacy compliance** - No PII in attribution codes
- ✅ **Registry verification** - Checks code registration

## 🎯 Benefits

### For Bot Hunter
- **Transparent tracking** of all game transactions
- **Reward distribution** to your payout address
- **Analytics dashboard** on base.dev
- **Ecosystem recognition** as an active builder

### For Users
- **No extra cost** - Attribution suffix adds ~50 bytes
- **Better rewards** - Enables builder incentive programs
- **Transparent** - Attribution visible on-chain

## 🔮 Future Extensions

### Planned Features
- 🔄 **On-chain leaderboard** with attributed transactions
- 🎁 **NFT rewards** for achievements (Bot Slayer badges)
- 🪙 **Token rewards** distributed via attribution tracking
- 📊 **Real-time analytics** dashboard in-game

### Integration Opportunities
- **Base-Solana bridge** attribution via `hookData`
- **Cross-chain attribution** with custom registries
- **Partner integrations** for multi-app attribution

## 📚 Resources

- **Base Builder Codes Docs:** [https://docs.base.org/builders/builder-codes](https://docs.base.org/builders/builder-codes)
- **ERC-8021 Spec:** [https://ethereum-magicians.org/t/erc-8021-transaction-attribution/25561](https://ethereum-magicians.org/t/erc-8021-transaction-attribution/25561)
- **Base.dev Dashboard:** [https://base.dev](https://base.dev)
- **Wagmi Docs:** [https://wagmi.sh](https://wagmi.sh)

## ⚠️ Important Notes

### Before Production Deployment

1. ✅ **Register on base.dev** - Get official Builder Code
2. ✅ **Update `code` in config** - ✅ Real code `bc_9b19fklw` configured
3. ✅ **Add `base:app_id`** - Update layout.tsx metadata
4. ✅ **Test on Base Sepolia** - Verify attribution works
5. ✅ **Check analytics** - Confirm transactions appear on base.dev

### Known Limitations

- **Builder Code must be registered** on Base canonical registry
- **Schema 0 only** (canonical registry) - Schema 1 (custom registry) ready but not used
- **Wallet support varies** - Not all wallets support `wallet_sendCalls` yet
- **Legacy fallback available** - `writeContract` with manual suffix appending

## 🆘 Troubleshooting

### Transaction fails with "Invalid capability"
- **Cause:** Wallet doesn't support `dataSuffix` capability
- **Fix:** Use legacy attribution with `writeContract`

### Attribution not showing on base.dev
- **Cause:** Builder Code not registered or incorrect
- **Fix:** Verify code on base.dev dashboard, update config

### TypeScript errors with wagmi hooks
- **Cause:** Missing dependencies or version mismatch
- **Fix:** Ensure all dependencies installed correctly

### Suffix not appearing in transaction
- **Cause:** Attribution hook not used, or capability not passed
- **Fix:** Use `useAttributedTransaction` hook, check capability

## ✅ Current Status

| Feature | Status |
|---------|--------|
| ERC-8021 Encoding | ✅ Complete |
| Wagmi Integration | ✅ Complete |
| Attribution Hooks | ✅ Complete |
| Multi-Entity Support | ✅ Complete |
| Security Validation | ✅ Complete |
| Documentation | ✅ Complete |
| Builder Code | ✅ Active (`bc_9b19fklw`) |
| base:app_id | ⚠️ Pending Registration |
| Production Testing | ⏳ Ready for Testnet |

---

**Next Step:** Register on [base.dev](https://base.dev) to get your Builder Code and complete the integration! 🚀
