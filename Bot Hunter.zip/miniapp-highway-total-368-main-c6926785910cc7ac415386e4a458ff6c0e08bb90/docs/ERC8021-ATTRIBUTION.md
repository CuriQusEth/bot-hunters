# ERC-8021 Transaction Attribution - Bot Hunter Implementation

## 🎯 Overview

Bot Hunter implements **ERC-8021 Transaction Attribution**, a standardized method for attributing blockchain transactions to applications and wallets. This enables:

- **Interoperable Attribution**: Standardized format recognized across the ecosystem
- **Reward Distribution**: Direct rewards to Bot Hunter's payout address
- **Multi-Entity Support**: Attribute to both app and wallet simultaneously
- **Analytics**: Track game engagement and transaction origins
- **Extensible**: Future-proof design supporting new schemas

## 📋 Standard Reference

- **ERC-8021**: Transaction Attribution
- **Author**: Conner Swenberg (@ilikesymmetry)
- **Discussion**: [Ethereum Magicians](https://ethereum-magicians.org/t/erc-8021-transaction-attribution/25561)
- **Requires**: ERC-4337, EIP-5792

## 🏗️ Architecture

### File Structure

```
src/
├── types/
│   └── erc8021.ts           # Type definitions
├── lib/
│   ├── erc8021.ts            # Core encoding/parsing utilities
│   ├── attribution.ts        # Bot Hunter specific attribution
│   └── erc8021-examples.ts   # Usage examples
└── docs/
    └── ERC8021-ATTRIBUTION.md # This file
```

### Core Components

1. **Types** (`src/types/erc8021.ts`)
   - Schema configurations
   - Code Registry interface
   - Attribution data structures

2. **Utilities** (`src/lib/erc8021.ts`)
   - Encoding functions (Schema 0 & 1)
   - Parsing functions
   - Validation helpers
   - ERC-5792 integration

3. **Bot Hunter Attribution** (`src/lib/attribution.ts`)
   - Pre-configured Bot Hunter attribution
   - Helper functions for game transactions
   - Multi-entity attribution support

## 🚀 Quick Start

### Basic Usage

```typescript
import { addBotHunterAttribution } from '@/lib/attribution';

// Original transaction calldata
const calldata = '0x095ea7b3000000000000000000000000...';

// Add Bot Hunter attribution
const attributedCalldata = addBotHunterAttribution(calldata);

// Use in transaction
await wallet.sendTransaction({
  to: contractAddress,
  data: attributedCalldata,
});
```

### Multi-Entity Attribution

```typescript
import { createMultiAttribution, appendAttribution } from '@/lib/attribution';

// Attribute to both Bot Hunter and wallet
const config = createMultiAttribution('coinbase');
const attributedCalldata = appendAttribution(calldata, config);
```

### Parsing Attribution

```typescript
import { parseAttribution } from '@/lib/erc8021';

const parsed = parseAttribution(txCalldata);

if (parsed) {
  console.log('Codes:', parsed.codes); // ['bothunter']
  console.log('Schema:', parsed.schemaId); // 0
}
```

## 📝 Attribution Format

### Data Suffix Structure

Attribution data is appended to transaction calldata in reverse order:

```
{txData}{schemaData}{schemaId}{ercSuffix}
```

### Components

- **ercSuffix** (16 bytes): `0x80218021802180218021802180218021` - Standard identifier
- **schemaId** (1 byte): Schema version (0 or 1)
- **schemaData** (variable): Schema-specific data

### Schema 0: Canonical Registry

Uses chain's canonical Code Registry (e.g., Base mainnet)

```
{txData}{codes}{codesLength}{schemaId}{ercSuffix}
```

Example: Single attribution
```
{txData}{"bothunter"}{9}{0}{0x80218021802180218021802180218021}
```

Example: Multi-entity attribution
```
{txData}{"bothunter,coinbase"}{17}{0}{0x80218021802180218021802180218021}
```

### Schema 1: Custom Registry

Specifies custom Code Registry on any chain

```
{txData}{codes}{codesLength}{chainId}{chainIdLength}{registryAddress}{schemaId}{ercSuffix}
```

Example:
```
{txData}{"bothunter"}{9}{8453}{2}{0x1234...}{1}{0x80218021802180218021802180218021}
```

## 🔧 Implementation Details

### Attribution Code: `bothunter`

Bot Hunter uses the attribution code **`bothunter`** which:
- Follows 7-bit ASCII encoding
- Contains no commas (reserved as delimiter)
- Is registered in Base's canonical Code Registry
- Links to Bot Hunter's payout address and metadata

### Code Registry Interface

```solidity
interface ICodeRegistry {
    function payoutAddress(string memory code) external view returns (address);
    function codeURI(string memory code) external view returns (string memory);
    function isValidCode(string memory code) external view returns (bool);
    function isRegistered(string memory code) external view returns (bool);
}
```

### Canonical Registries

| Chain | Chain ID | Registry Address |
|-------|----------|------------------|
| Base Mainnet | 8453 | TBD |
| Base Sepolia | 84532 | TBD |

## 🎮 Game Integration Scenarios

### 1. NFT Reward Claims

When players claim NFT rewards for achievements:

```typescript
import { prepareAttributedCall } from '@/lib/attribution';

// Prepare NFT mint with attribution
const call = prepareAttributedCall(
  nftContractAddress,
  mintFunctionCalldata
);

await wallet.sendTransaction(call);
```

### 2. Smart Account Transactions (ERC-4337)

For smart wallet/account transactions:

```typescript
import { prepareUserOpWithAttribution } from '@/lib/attribution';

const userOp = {
  sender: accountAddress,
  callData: prepareUserOpWithAttribution(calldata),
  // ... other UserOperation fields
};

await bundler.sendUserOperation(userOp);
```

### 3. ERC-5792 wallet_sendCalls

For batch transactions:

```typescript
import { createDataSuffixCapability } from '@/lib/erc8021';
import { BOT_HUNTER_ATTRIBUTION } from '@/lib/attribution';

const capability = createDataSuffixCapability(BOT_HUNTER_ATTRIBUTION);

await provider.request({
  method: 'wallet_sendCalls',
  params: [{
    version: '1.0',
    from: userAddress,
    calls: [/* ... */],
    capabilities: capability,
  }],
});
```

## 📊 Analytics & Tracking

### Transaction Attribution Rate

```typescript
import { parseAttribution } from '@/lib/erc8021';

function calculateAttributionRate(transactions: string[]) {
  let attributed = 0;
  
  transactions.forEach(tx => {
    if (parseAttribution(tx.data)) {
      attributed++;
    }
  });
  
  return (attributed / transactions.length * 100).toFixed(2);
}
```

### Code Frequency Analysis

```typescript
function analyzeAttributions(transactions: string[]) {
  const codeFrequency = new Map<string, number>();
  
  transactions.forEach(tx => {
    const parsed = parseAttribution(tx.data);
    parsed?.codes.forEach(code => {
      codeFrequency.set(code, (codeFrequency.get(code) || 0) + 1);
    });
  });
  
  return codeFrequency;
}
```

## 🎁 Reward Distribution

### How It Works

1. **Transaction Attribution**: Bot Hunter appends attribution suffix to transactions
2. **On-Chain Parsing**: Protocols parse attribution data from calldata
3. **Registry Query**: Query Code Registry for `bothunter` payout address
4. **Reward Distribution**: Send rewards to Bot Hunter's address
5. **Player Benefits**: Bot Hunter can distribute rewards to active players

### Example Reward Flow

```
Player Transaction
  ↓ (with bothunter attribution)
Protocol Contract
  ↓ (parses attribution)
Code Registry
  ↓ (returns payout address)
Reward Distribution
  ↓
Bot Hunter Treasury
  ↓
Player Rewards
```

## 🔒 Security Considerations

### Code Validation

Always validate attribution codes before encoding:

```typescript
import { isValidCode, areValidCodes } from '@/lib/erc8021';

// Validate single code
if (!isValidCode(code)) {
  throw new Error('Invalid attribution code');
}

// Validate multiple codes
if (!areValidCodes(codes)) {
  throw new Error('One or more codes are invalid');
}
```

### Requirements

- Must be 7-bit ASCII (0x00 - 0x7F)
- Must NOT contain commas (0x2C)
- Must NOT be empty string
- Total codes length must not exceed 255 bytes

## 🚧 Future Enhancements

### Planned Features

1. **On-Chain Code Registry**: Deploy Bot Hunter's own registry on Base
2. **Reward Claiming UI**: Interface for players to claim attribution rewards
3. **Analytics Dashboard**: Track attribution metrics and engagement
4. **Automatic Attribution**: Auto-append to all game transactions
5. **Multi-Chain Support**: Extend to other chains beyond Base

### Schema Extensions

Future ERCs may introduce new schemas with additional features:
- Schema 2+: Enhanced metadata support
- Cross-chain attribution tracking
- Dynamic reward distribution rules

## 📚 Resources

### Documentation

- [ERC-8021 Specification](https://ethereum-magicians.org/t/erc-8021-transaction-attribution/25561)
- [Usage Examples](../src/lib/erc8021-examples.ts)
- [Type Definitions](../src/types/erc8021.ts)

### Tools

- **Encoding**: `encodeSchema0()`, `encodeSchema1()`
- **Parsing**: `parseAttribution()`
- **Validation**: `isValidCode()`, `areValidCodes()`
- **Integration**: `appendAttribution()`, `createDataSuffixCapability()`

## 🤝 Contributing

To add new attribution features:

1. Update types in `src/types/erc8021.ts`
2. Implement utilities in `src/lib/erc8021.ts`
3. Add game-specific helpers to `src/lib/attribution.ts`
4. Create examples in `src/lib/erc8021-examples.ts`
5. Update this documentation

## 📞 Support

For questions or issues related to ERC-8021 attribution:

- Check [Usage Examples](../src/lib/erc8021-examples.ts)
- Review [Type Definitions](../src/types/erc8021.ts)
- Consult [ERC-8021 Discussion](https://ethereum-magicians.org/t/erc-8021-transaction-attribution/25561)

---

**Bot Hunter** - Protecting the feed, one attributed transaction at a time 🎯🤖
