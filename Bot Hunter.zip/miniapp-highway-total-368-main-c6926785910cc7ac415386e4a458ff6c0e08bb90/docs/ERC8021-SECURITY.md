# ERC-8021 Security & Implementation Guide

## 🔒 Security Overview

Bot Hunter implements comprehensive security measures for ERC-8021 transaction attribution, following all security considerations from the specification.

## 🛡️ Security Features

### 1. **Parsing Safety**

All attribution parsing includes robust error handling to prevent malicious data from causing failures:

```typescript
import { safeParseAttribution } from '@/lib/erc8021-security';

// Safe parsing with comprehensive error handling
const { result, error } = safeParseAttribution(calldata);

if (error) {
  console.warn('Attribution parsing failed:', error);
  // Continue with transaction without attribution
}
```

**Protection against:**
- Buffer underflow/overflow attacks
- Malformed data causing parse errors
- Invalid ERC suffixes
- Corrupted length bytes
- Unknown schema IDs

### 2. **Data Integrity Verification**

Verify that attribution data hasn't been tampered with:

```typescript
import { verifyDataIntegrity } from '@/lib/erc8021-security';

const isIntact = verifyDataIntegrity(originalCalldata, receivedCalldata);

if (!isIntact) {
  console.error('Data integrity check failed!');
  // Handle potential tampering
}
```

**Note:** For cryptographic proof of attribution, implement signature-based verification as an additional layer.

### 3. **Code Validation**

All attribution codes undergo strict validation:

```typescript
import { validateAttributionConfig } from '@/lib/erc8021-security';

const validation = validateAttributionConfig(config);

if (!validation.valid) {
  console.error('Configuration errors:', validation.errors);
  // Fix configuration before proceeding
}

if (validation.warnings.length > 0) {
  console.warn('Configuration warnings:', validation.warnings);
  // Review warnings for potential issues
}
```

**Validation checks:**
- ✅ 7-bit ASCII encoding
- ✅ No commas (reserved delimiter)
- ✅ Non-empty codes
- ✅ Valid registry addresses (Schema 1)
- ✅ Positive chain IDs
- ⚠️ No potentially identifying information
- ⚠️ Reasonable code lengths

### 4. **Privacy Compliance**

Automatic privacy checks prevent accidental inclusion of sensitive data:

```typescript
import { checkPrivacyCompliance } from '@/lib/erc8021-security';

const warnings = checkPrivacyCompliance(config);

if (warnings.length > 0) {
  console.warn('Privacy warnings:', warnings);
  // Review codes for PII
}
```

**Privacy patterns detected:**
- User identifiers
- Address information
- Wallet identifiers
- Numeric sequences (potential IDs)

### 5. **Registry Security**

Registry address validation ensures safe registry usage:

```typescript
import { validateRegistryAddress } from '@/lib/erc8021-security';

const validation = validateRegistryAddress(registryAddress);

if (!validation.valid) {
  console.error('Invalid registry:', validation.errors);
  // Do not use this registry
}
```

**Registry checks:**
- ✅ Proper address format
- ✅ Not zero address
- ⚠️ Checksum validation

### 6. **Rate Limiting**

Prevent DOS attacks from malicious attribution operations:

```typescript
import { AttributionRateLimiter } from '@/lib/erc8021-security';

const rateLimiter = new AttributionRateLimiter(10, 60000); // 10 attempts per minute

if (!rateLimiter.isAllowed(userAddress)) {
  console.warn('Rate limit exceeded');
  // Reject operation
  return;
}

// Proceed with attribution operation
```

### 7. **Code Sanitization**

Sanitize potentially malicious codes:

```typescript
import { sanitizeCode } from '@/lib/erc8021-security';

const sanitized = sanitizeCode(userProvidedCode);

if (!sanitized) {
  console.error('Code cannot be sanitized');
  // Reject code
} else {
  // Use sanitized code
}
```

## 🧪 Testing

### Comprehensive Test Suite

Run the complete ERC-8021 test suite:

```typescript
import { runERC8021Tests } from '@/lib/erc8021-tests';

// Run all tests
const results = runERC8021Tests();

// Results are automatically printed to console
```

### Quick Validation

Validate your implementation:

```typescript
import { validateERC8021Implementation } from '@/lib/erc8021-tests';

const isValid = validateERC8021Implementation();

if (!isValid) {
  console.error('Implementation has errors!');
  // Review test output
}
```

### Test Coverage

Our test suite includes:

1. **Specification Test Cases:**
   - ✅ Single entity + canonical registry
   - ✅ Multi-entity + custom registry
   - ✅ Invalid schema ID handling

2. **Security Tests:**
   - ✅ Malformed data handling
   - ✅ Empty code rejection
   - ✅ Comma in code rejection
   - ✅ Non-ASCII character rejection
   - ✅ Buffer overflow protection

3. **Edge Cases:**
   - ✅ Maximum length codes (255 bytes)
   - ✅ Code length overflow (256+ bytes)
   - ✅ Backward compatibility

4. **Integration Tests:**
   - ✅ Parsing round-trip (encode → decode)
   - ✅ Multi-schema support
   - ✅ Transaction data preservation

## 🔧 Configuration

### Bot Hunter Configuration

```typescript
import { BOT_HUNTER_CONFIG } from '@/config/erc8021';

console.log('Code:', BOT_HUNTER_CONFIG.code);
// Output: bothunter

console.log('Payout Address:', BOT_HUNTER_CONFIG.payoutAddress);
// Output: 0x29536D0bc1004ab274c4F0F59734Ad74D4559b7B

console.log('Network:', BOT_HUNTER_CONFIG.network.name);
// Output: Base
```

### Validate Configuration

```typescript
import { validateConfig } from '@/config/erc8021';

const { valid, errors } = validateConfig();

if (!valid) {
  console.error('Configuration errors:', errors);
}
```

## 🎯 Best Practices

### 1. **Always Validate Before Encoding**

```typescript
import { validateAttributionConfig } from '@/lib/erc8021-security';
import { encodeAttribution } from '@/lib/erc8021';

// ❌ BAD: Encode without validation
const suffix = encodeAttribution(config);

// ✅ GOOD: Validate first
const validation = validateAttributionConfig(config);
if (validation.valid) {
  const suffix = encodeAttribution(config);
} else {
  // Handle validation errors
}
```

### 2. **Use Safe Parsing**

```typescript
import { safeParseAttribution } from '@/lib/erc8021-security';

// ❌ BAD: Direct parsing can throw
const parsed = parseAttribution(calldata);

// ✅ GOOD: Safe parsing with error handling
const { result, error } = safeParseAttribution(calldata);
if (result) {
  // Use parsed attribution
}
```

### 3. **Implement Rate Limiting**

```typescript
import { AttributionRateLimiter } from '@/lib/erc8021-security';

const rateLimiter = new AttributionRateLimiter();

// Check before expensive operations
if (rateLimiter.isAllowed(userIdentifier)) {
  // Process attribution
} else {
  // Reject with 429 Too Many Requests
}
```

### 4. **Check Privacy Compliance**

```typescript
import { checkPrivacyCompliance } from '@/lib/erc8021-security';

// Before registering codes
const warnings = checkPrivacyCompliance(config);
if (warnings.length > 0) {
  // Review and fix privacy issues
}
```

### 5. **Verify Registry Trust**

```typescript
import { validateRegistryAddress } from '@/lib/erc8021-security';

// Before using custom registry
const validation = validateRegistryAddress(registryAddress);
if (!validation.valid) {
  // Use canonical registry instead
}
```

## 🔐 Security Audit Checklist

Run complete security audit:

```typescript
import { auditAttributionSecurity } from '@/lib/erc8021-security';

const audit = auditAttributionSecurity(config);

console.log('Security Audit:');
console.log('Valid:', audit.valid);
console.log('Errors:', audit.errors);
console.log('Warnings:', audit.warnings);
```

### Pre-Deployment Checklist

- [ ] All tests pass (`validateERC8021Implementation()`)
- [ ] Configuration validated (`validateConfig()`)
- [ ] No security errors in audit
- [ ] Privacy warnings reviewed
- [ ] Rate limiting implemented
- [ ] Error handling in place
- [ ] Registry addresses verified

## 📊 Mock Registry

For testing and development, use the mock registry:

```typescript
import { mockRegistry } from '@/lib/erc8021-registry-mock';

// Get Bot Hunter payout address
const address = await mockRegistry.payoutAddress('bothunter');
// Output: 0x29536D0bc1004ab274c4F0F59734Ad74D4559b7B

// Check registration
const isRegistered = await mockRegistry.isRegistered('bothunter');
// Output: true

// Get metadata
const metadata = await mockRegistry.getMetadata('bothunter');
// Output: { app: { name: 'Bot Hunter', url: 'https://bothunter.app' } }
```

## 🚨 Common Security Issues

### Issue 1: Unvalidated User Input

```typescript
// ❌ VULNERABLE
function createAttribution(userCode: string) {
  return encodeSchema0([userCode]);
}

// ✅ SECURE
function createAttribution(userCode: string) {
  const sanitized = sanitizeCode(userCode);
  if (!sanitized) {
    throw new Error('Invalid code');
  }
  return encodeSchema0([sanitized]);
}
```

### Issue 2: Missing Error Handling

```typescript
// ❌ VULNERABLE
const parsed = parseAttribution(untrustedData);
processAttribution(parsed.codes); // Can crash if null

// ✅ SECURE
const { result, error } = safeParseAttribution(untrustedData);
if (result) {
  processAttribution(result.codes);
} else {
  console.warn('Parse failed:', error);
}
```

### Issue 3: No Rate Limiting

```typescript
// ❌ VULNERABLE
app.post('/attribution', (req, res) => {
  const attribution = encodeAttribution(req.body);
  res.json({ attribution });
});

// ✅ SECURE
const rateLimiter = new AttributionRateLimiter();

app.post('/attribution', (req, res) => {
  if (!rateLimiter.isAllowed(req.ip)) {
    return res.status(429).json({ error: 'Rate limit exceeded' });
  }
  
  const attribution = encodeAttribution(req.body);
  res.json({ attribution });
});
```

## 📚 Additional Resources

- [ERC-8021 Specification](https://ethereum-magicians.org/t/erc-8021-transaction-attribution/25561)
- [Bot Hunter Documentation](./ERC8021-ATTRIBUTION.md)
- [Quick Start Guide](../README-ERC8021.md)

## 🆘 Support

If you discover security issues:
1. DO NOT open a public issue
2. Contact security@bothunter.app
3. Include detailed description and reproduction steps

---

**Last Updated:** 2025-01-22  
**Version:** 1.0.0  
**Status:** Production Ready ✅
