# Web3 Integration Quick Start

## 🎮 Bot Hunter + Web3

Bot Hunter now has **full Web3 capabilities** powered by Wagmi, Viem, and ERC-8021 transaction attribution. This guide helps you get started quickly.

## ⚡ Quick Setup (5 Minutes)

### 1. Get Your Credentials

Register on [base.dev](https://base.dev) to receive:
- **Builder Code** (e.g., `k3p9da`)
- **base:app_id** (e.g., `68f40c278c4fe3f562003d93`)

### 2. Update Configuration

**File 1:** `src/config/erc8021.ts` (line 18)
```typescript
code: 'YOUR_BUILDER_CODE_HERE', // ← Replace 'bothunter'
```

**File 2:** `src/app/layout.tsx` (line 52)
```typescript
"base:app_id": "YOUR_APP_ID_HERE" // ← Uncomment and add
```

### 3. Deploy

```bash
npm run build
npm run start
```

Done! All transactions now include Bot Hunter attribution. 🎉

---

## 🚀 Usage Examples

### Send NFT Reward

```typescript
'use client';

import { useAttributedTransaction } from '@/hooks/useAttributedTransaction';
import { encodeFunctionData } from 'viem';
import { Button } from '@/components/ui/button';

export function RewardButton() {
  const { sendWithAttribution, isPending } = useAttributedTransaction();

  async function claimReward() {
    const calldata = encodeFunctionData({
      abi: NFT_ABI,
      functionName: 'mint',
      args: [userAddress, tokenId],
    });

    await sendWithAttribution([{
      to: NFT_CONTRACT_ADDRESS,
      data: calldata,
      value: 0n
    }]);
  }

  return (
    <Button onClick={claimReward} disabled={isPending}>
      Claim Bot Slayer NFT
    </Button>
  );
}
```

### Send ETH with Attribution

```typescript
import { useAttributedTransaction } from '@/hooks/useAttributedTransaction';

export function SendEthButton() {
  const { sendWithAttribution } = useAttributedTransaction();

  async function sendEth() {
    await sendWithAttribution([{
      to: '0xRecipient',
      value: parseEther('0.001'), // 0.001 ETH
    }]);
  }

  return <button onClick={sendEth}>Send 0.001 ETH</button>;
}
```

### Multi-Entity Attribution

```typescript
import { useMultiEntityAttribution } from '@/hooks/useMultiEntityAttribution';

export function MultiAttributeButton() {
  // Attribute to both Bot Hunter + Coinbase Wallet
  const { sendWithMultiAttribution } = useMultiEntityAttribution('coinbase');

  async function sendTx() {
    await sendWithMultiAttribution([{
      to: '0xContract',
      data: calldata,
    }]);
  }

  return <button onClick={sendTx}>Send Transaction</button>;
}
```

---

## 📚 Available Hooks

### `useAttributedTransaction()`

Main hook for attributed transactions.

```typescript
const { 
  sendWithAttribution,  // Send transactions with attribution
  isPending,            // Loading state
  error                 // Error object if failed
} = useAttributedTransaction();
```

### `useSingleAttributedTransaction()`

Convenience wrapper for single transactions.

```typescript
const { 
  sendSingleWithAttribution,  // Send single transaction
  isPending,
  error
} = useSingleAttributedTransaction();
```

### `useMultiEntityAttribution(walletCode?)`

Multi-entity attribution (app + wallet).

```typescript
const { 
  sendWithMultiAttribution,  // Send with multi-entity attribution
  isPending,
  error
} = useMultiEntityAttribution('coinbase'); // Optional wallet code
```

---

## 🎯 Future Game Features

### Phase 1: NFT Rewards
- **Bot Slayer Badge** - Mint NFT for 100+ bots eliminated
- **Feed Guardian** - Mint NFT for 95%+ accuracy
- **Combo Master** - Mint NFT for 50+ combo streak

### Phase 2: On-Chain Leaderboard
- Store high scores on-chain
- Weekly competitions with token rewards
- Global rankings with attribution tracking

### Phase 3: Token Economy
- **$HUNTER token** for rewards
- Stake tokens to unlock power-ups
- Trade achievements as NFTs

---

## 🔍 Verification

### Check Attribution on Basescan

1. Send a transaction
2. Open [Basescan](https://basescan.org)
3. Find your transaction
4. View **Input Data**
5. Verify suffix: `...80218021802180218021802180218021`

### View Analytics

1. Log in to [base.dev](https://base.dev)
2. View your app dashboard
3. See transaction attribution stats

---

## 📦 What's Included

### Dependencies
- ✅ `wagmi` - React Hooks for Ethereum
- ✅ `viem` - TypeScript Ethereum library
- ✅ `ox` - ERC-8021 helpers
- ✅ `@tanstack/react-query` - Data fetching
- ✅ `@wagmi/core` - Core utilities

### Configuration
- ✅ Base mainnet (Chain ID: 8453)
- ✅ Base Sepolia testnet (Chain ID: 84532)
- ✅ Coinbase Wallet connector
- ✅ MetaMask connector
- ✅ WalletConnect connector

### Security
- ✅ Parsing validation
- ✅ Code format verification
- ✅ Buffer overflow protection
- ✅ Privacy compliance
- ✅ Test suite (28 tests passing)

---

## 🆘 Common Issues

### "Module not found: Can't resolve 'wagmi'"
**Fix:** Ensure dependencies are installed:
```bash
npm install wagmi viem ox @tanstack/react-query @wagmi/core
```

### "Property 'sendCalls' does not exist"
**Fix:** Import from experimental:
```typescript
import { useSendCalls } from 'wagmi/experimental';
```

### Attribution not appearing
**Fix:** Ensure Builder Code is registered on base.dev and updated in config.

---

## 📚 Documentation

- **Full Integration Guide:** `docs/BASE-BUILDER-CODES-INTEGRATION.md`
- **ERC-8021 Spec:** `docs/ERC8021-ATTRIBUTION.md`
- **Security Guide:** `docs/ERC8021-SECURITY.md`
- **Test Suite:** `src/lib/erc8021.test.ts`

---

## 🚀 Next Steps

1. **Register on base.dev** - Get your Builder Code
2. **Update config files** - Add your credentials
3. **Test on Sepolia** - Verify attribution works
4. **Build game features** - Add NFT rewards, leaderboards
5. **Deploy to mainnet** - Go live with attribution!

---

**Happy Building!** 🎮⚡

Questions? Check the [full documentation](./BASE-BUILDER-CODES-INTEGRATION.md) or reach out to the Base community.
