/**
 * Bot Hunter Transaction Attribution
 * 
 * Configures ERC-8021 attribution for Bot Hunter game transactions
 * Enables tracking and reward distribution for app usage
 */

import type { Schema0Config } from '@/types/erc8021';
import { appendAttribution, encodeAttribution } from './erc8021';
import { BOT_HUNTER_CONFIG, DEFAULT_ATTRIBUTION_CONFIG } from '@/config/erc8021';

/**
 * Bot Hunter attribution code
 * Registered in Base canonical Code Registry
 */
export const BOT_HUNTER_CODE = BOT_HUNTER_CONFIG.code;

/**
 * Bot Hunter payout address for rewards
 */
export const BOT_HUNTER_PAYOUT_ADDRESS = BOT_HUNTER_CONFIG.payoutAddress;

/**
 * Base attribution configuration for Bot Hunter
 * Uses Schema 0 with Base's canonical registry
 */
export const BOT_HUNTER_ATTRIBUTION: Schema0Config = DEFAULT_ATTRIBUTION_CONFIG;

/**
 * Get attribution suffix for Bot Hunter transactions
 * 
 * @returns Hex-encoded attribution suffix
 */
export function getBotHunterAttribution(): string {
  return encodeAttribution(BOT_HUNTER_ATTRIBUTION);
}

/**
 * Append Bot Hunter attribution to transaction calldata
 * 
 * @param calldata Original transaction calldata
 * @returns Calldata with Bot Hunter attribution suffix
 */
export function addBotHunterAttribution(calldata: string): string {
  return appendAttribution(calldata, BOT_HUNTER_ATTRIBUTION);
}

/**
 * Creates multi-entity attribution for Bot Hunter + wallet
 * Useful when both app and wallet want attribution
 * 
 * @param walletCode Wallet attribution code (e.g., "coinbase", "rainbow")
 * @returns Attribution configuration with both codes
 */
export function createMultiAttribution(walletCode: string): Schema0Config {
  return {
    schemaId: 0,
    codes: [BOT_HUNTER_CODE, walletCode],
  };
}

/**
 * Prepare transaction data with attribution for ERC-4337 User Operations
 * Use this for smart account transactions
 * 
 * @param userOpCallData User operation calldata
 * @returns Calldata with attribution suffix for userOp.callData field
 */
export function prepareUserOpWithAttribution(userOpCallData: string): string {
  return addBotHunterAttribution(userOpCallData);
}

/**
 * Example: Prepare a contract call with attribution
 * 
 * @param contractAddress Target contract address
 * @param calldata Function call data
 * @returns Transaction object with attribution
 */
export function prepareAttributedCall(contractAddress: string, calldata: string) {
  return {
    to: contractAddress,
    data: addBotHunterAttribution(calldata),
    value: '0x0',
  };
}
