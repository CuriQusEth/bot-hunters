import type { Cast } from '@/types/game'

const botUsernames: string[] = [
  'crypto_prophet_9999',
  'moonshot_master',
  'airdrop_alert_bot',
  'scam_ai_3000',
  'warplord4200',
  'profit_guru_x',
  'free_money_now',
  'quick_gains_ai',
  'shiller_supreme',
  'pump_dumper_pro',
  'nft_sniper_bot',
  'lambo_incoming',
  'guaranteed_profit',
  'instant_rich_ai'
]

const realUsernames: string[] = [
  'v',
  'dwr.eth',
  'jessepollak',
  'adrienne',
  'horsefacts',
  'proxystudio.eth',
  'alok',
  'ted',
  'cassie',
  'rish',
  'colin',
  'sm-sbs',
  'christin',
  'jayme'
]

const botContent: string[] = [
  '🚀 FREE AIRDROP NOW!! 100X GUARANTEED!!!',
  '💰 Check my new memecoin!! Instant profit!',
  '🔥 GUARANTEED 1000X RETURNS!! JOIN NOW!!',
  '💎 Follow for instant profit secrets!!',
  '⚡ WARP TOKEN LAUNCHING!! GET IN EARLY!!!',
  '🎯 HUGE AIRDROP ALERT!! Click link below!!',
  '🌙 TO THE MOON!! 🚀🚀🚀 BUY NOW!!!',
  '💸 FREE MONEY!! Limited spots available!!',
  '🎰 100% WIN RATE TRADING BOT!! Sign up!!',
  '🔮 REVOLUTIONARY NEW CHAIN!! Early access!!',
  '💵 PASSIVE INCOME GUARANTEED!! Join telegram!!',
  '🎁 FREE NFT MINT!! Only 100 left!!',
  '🌟 NEXT BIG THING!! Don\'t miss out!!',
  '💰💰💰 MAKE MONEY FAST!! Click here!!'
]

const realContent: string[] = [
  'gm fren ☀️',
  'just shipped a new frame 🚀',
  'what\'s your favorite cast of the week?',
  'building in public is wild',
  'excited about this new protocol',
  'great conversation in the replies',
  'onchain summer hitting different',
  'based takes only',
  'love this community',
  'shipping something cool soon',
  'who else is building rn?',
  'thoughts on the latest update?',
  'grateful for all the support',
  'let\'s make something together'
]

const avatarColors: string[] = [
  'bg-purple-500',
  'bg-blue-500',
  'bg-green-500',
  'bg-yellow-500',
  'bg-pink-500',
  'bg-red-500',
  'bg-indigo-500',
  'bg-teal-500'
]

export function generateCast(id: string): Cast {
  const isBot: boolean = Math.random() > 0.4
  const username: string = isBot 
    ? botUsernames[Math.floor(Math.random() * botUsernames.length)]
    : realUsernames[Math.floor(Math.random() * realUsernames.length)]
  const content: string = isBot
    ? botContent[Math.floor(Math.random() * botContent.length)]
    : realContent[Math.floor(Math.random() * realContent.length)]
  const avatarColor: string = avatarColors[Math.floor(Math.random() * avatarColors.length)]
  
  return {
    id,
    type: isBot ? 'bot' : 'real',
    username,
    content,
    avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${username}&backgroundColor=${avatarColor}`,
    timestamp: Date.now(),
    position: 0
  }
}
