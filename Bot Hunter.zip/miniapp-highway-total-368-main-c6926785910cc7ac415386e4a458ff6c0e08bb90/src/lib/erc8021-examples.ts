/**
 * ERC-8021 Transaction Attribution - Usage Examples
 * 
 * Demonstrates how to use ERC-8021 attribution in various scenarios
 */

import {
  encodeSchema0,
  encodeSchema1,
  appendAttribution,
  parseAttribution,
  createDataSuffixCapability,
  isValidCode,
} from './erc8021';
import {
  getBotHunterAttribution,
  addBotHunterAttribution,
  createMultiAttribution,
  prepareUserOpWithAttribution,
  prepareAttributedCall,
} from './attribution';
import type { AttributionConfig } from '@/types/erc8021';

/**
 * Example 1: Basic Bot Hunter Attribution (Schema 0)
 * 
 * Adds "bothunter" attribution to a transaction using Base's canonical registry
 */
export function exampleBasicAttribution() {
  // Original transaction calldata
  const originalCalldata = '0x095ea7b3000000000000000000000000...';

  // Add Bot Hunter attribution
  const attributedCalldata = addBotHunterAttribution(originalCalldata);

  console.log('Original:', originalCalldata);
  console.log('With Attribution:', attributedCalldata);

  return attributedCalldata;
}

/**
 * Example 2: Multi-Entity Attribution
 * 
 * Attributes transaction to both Bot Hunter and a wallet (e.g., Coinbase Wallet)
 */
export function exampleMultiEntityAttribution() {
  const originalCalldata = '0x095ea7b3000000000000000000000000...';

  // Create multi-entity attribution config
  const multiConfig = createMultiAttribution('coinbase');

  // Append attribution
  const attributedCalldata = appendAttribution(originalCalldata, multiConfig);

  console.log('Multi-Entity Attribution:', attributedCalldata);

  // Parse it back
  const parsed = parseAttribution(attributedCalldata);
  console.log('Parsed codes:', parsed?.codes); // ['bothunter', 'coinbase']

  return attributedCalldata;
}

/**
 * Example 3: Custom Registry (Schema 1)
 * 
 * Uses a custom Code Registry on a specific chain
 */
export function exampleCustomRegistry() {
  const originalCalldata = '0x095ea7b3000000000000000000000000...';

  // Schema 1 config with custom registry
  const customConfig: AttributionConfig = {
    schemaId: 1,
    codes: ['bothunter', 'customwallet'],
    codeRegistryChainId: 8453, // Base mainnet
    codeRegistryAddress: '0x1234567890123456789012345678901234567890',
  };

  const attributedCalldata = appendAttribution(originalCalldata, customConfig);

  console.log('Custom Registry Attribution:', attributedCalldata);

  // Parse it back
  const parsed = parseAttribution(attributedCalldata);
  console.log('Parsed:', parsed);

  return attributedCalldata;
}

/**
 * Example 4: ERC-5792 wallet_sendCalls Integration
 * 
 * Prepares attribution for wallet RPC calls
 */
export async function exampleWalletSendCalls() {
  // Create data suffix capability
  const capability = createDataSuffixCapability({
    schemaId: 0,
    codes: ['bothunter'],
  });

  // Use with wallet_sendCalls
  const calls = [
    {
      to: '0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb',
      value: '0x0',
      data: '0x095ea7b3000000000000000000000000...',
    },
  ];

  // In a real implementation, you would call:
  // await provider.request({
  //   method: 'wallet_sendCalls',
  //   params: [{
  //     version: '1.0',
  //     from: userAddress,
  //     calls,
  //     capabilities: {
  //       ...capability,
  //     },
  //   }],
  // });

  console.log('Data Suffix Capability:', capability);
  return capability;
}

/**
 * Example 5: ERC-4337 User Operation Attribution
 * 
 * Adds attribution to smart account transactions
 */
export function exampleUserOpAttribution() {
  // Smart account user operation calldata
  const userOpCallData = '0xb61d27f6000000000000000000000000...';

  // Prepare with attribution
  const attributedUserOpCallData = prepareUserOpWithAttribution(userOpCallData);

  // Use in user operation
  const userOp = {
    sender: '0x...',
    nonce: '0x1',
    initCode: '0x',
    callData: attributedUserOpCallData, // Attribution goes here
    callGasLimit: '0x...',
    verificationGasLimit: '0x...',
    preVerificationGas: '0x...',
    maxFeePerGas: '0x...',
    maxPriorityFeePerGas: '0x...',
    paymasterAndData: '0x',
    signature: '0x...',
  };

  console.log('User Operation with Attribution:', userOp);

  return userOp;
}

/**
 * Example 6: Parsing Attribution from Transaction
 * 
 * Extracts attribution data from transaction calldata
 */
export function exampleParseAttribution() {
  // Transaction with Bot Hunter attribution
  const txCalldata =
    '0x095ea7b3000000000000000000000000...' +
    '626f7468756e746572' + // "bothunter" in hex
    '09' + // codesLength = 9
    '00' + // schemaId = 0
    '80218021802180218021802180218021'; // ercSuffix

  const parsed = parseAttribution(txCalldata);

  if (parsed) {
    console.log('Schema ID:', parsed.schemaId);
    console.log('Codes:', parsed.codes);
    console.log('Registry:', parsed.codeRegistryAddress || 'Canonical');
  } else {
    console.log('No attribution found');
  }

  return parsed;
}

/**
 * Example 7: Validating Attribution Codes
 * 
 * Checks if codes are valid before encoding
 */
export function exampleCodeValidation() {
  const validCodes = ['bothunter', 'wallet', 'app123'];
  const invalidCodes = ['bot,hunter', 'émoji❌', '']; // comma, non-ASCII, empty

  validCodes.forEach((code) => {
    console.log(`${code}: ${isValidCode(code) ? 'Valid ✅' : 'Invalid ❌'}`);
  });

  invalidCodes.forEach((code) => {
    console.log(`${code}: ${isValidCode(code) ? 'Valid ✅' : 'Invalid ❌'}`);
  });
}

/**
 * Example 8: Real-World Transaction Flow
 * 
 * Complete flow from transaction creation to parsing
 */
export async function exampleCompleteFlow() {
  console.log('=== Complete ERC-8021 Attribution Flow ===\n');

  // Step 1: Create transaction
  console.log('1. Creating transaction...');
  const contractCall = prepareAttributedCall(
    '0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb',
    '0x095ea7b3000000000000000000000000...'
  );
  console.log('Transaction:', contractCall);

  // Step 2: Send transaction (pseudo-code)
  console.log('\n2. Sending transaction...');
  // const txHash = await wallet.sendTransaction(contractCall);
  // console.log('TX Hash:', txHash);

  // Step 3: Parse attribution from transaction
  console.log('\n3. Parsing attribution...');
  const parsed = parseAttribution(contractCall.data);
  console.log('Parsed Attribution:', parsed);

  // Step 4: Query Code Registry (pseudo-code)
  console.log('\n4. Querying Code Registry...');
  // const payoutAddress = await codeRegistry.payoutAddress('bothunter');
  // const metadata = await fetch(await codeRegistry.codeURI('bothunter'));
  // console.log('Payout Address:', payoutAddress);
  // console.log('Metadata:', metadata);

  return parsed;
}

/**
 * Example 9: Bot Hunter Game Transaction
 * 
 * Example of how Bot Hunter might attribute game-related transactions
 */
export function exampleGameTransaction() {
  // Example: Claiming an NFT reward for high score
  const claimNFTCalldata = '0x...'; // mint() function call

  // Add Bot Hunter attribution
  const attributedCalldata = addBotHunterAttribution(claimNFTCalldata);

  // This enables:
  // - Tracking which transactions came from Bot Hunter
  // - Distributing rewards to Bot Hunter's payout address
  // - Analytics on game engagement
  // - Potential reward sharing with players

  console.log('Game Transaction with Attribution:', attributedCalldata);

  return attributedCalldata;
}

/**
 * Example 10: Attribution Analytics
 * 
 * How to analyze attribution data from multiple transactions
 */
export function exampleAttributionAnalytics(transactions: string[]) {
  const analytics = {
    total: transactions.length,
    attributed: 0,
    codes: new Map<string, number>(),
    schemas: new Map<number, number>(),
  };

  transactions.forEach((txData) => {
    const parsed = parseAttribution(txData);

    if (parsed) {
      analytics.attributed++;

      // Count schema usage
      const schemaCount = analytics.schemas.get(parsed.schemaId) || 0;
      analytics.schemas.set(parsed.schemaId, schemaCount + 1);

      // Count code usage
      parsed.codes.forEach((code) => {
        const codeCount = analytics.codes.get(code) || 0;
        analytics.codes.set(code, codeCount + 1);
      });
    }
  });

  console.log('Attribution Analytics:', analytics);
  console.log('Attribution Rate:', `${(analytics.attributed / analytics.total * 100).toFixed(2)}%`);

  return analytics;
}
