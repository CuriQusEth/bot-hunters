/**
 * Mock Code Registry Implementation
 * 
 * In-memory implementation of ICodeRegistry interface for testing and development
 * This simulates a real on-chain Code Registry contract
 */

import type { ICodeRegistry, CodeMetadata } from '@/types/erc8021';

/**
 * Registry Entry
 */
interface RegistryEntry {
  code: string;
  payoutAddress: string;
  metadata: CodeMetadata;
  registered: boolean;
}

/**
 * Mock Code Registry for testing and development
 * Implements the ICodeRegistry interface
 */
export class MockCodeRegistry implements ICodeRegistry {
  private registry: Map<string, RegistryEntry> = new Map();

  constructor() {
    // Initialize with default Bot Hunter entry
    this.registerCode(
      'bothunter',
      '0x29536D0bc1004ab274c4F0F59734Ad74D4559b7B',
      {
        app: {
          name: 'Bot Hunter',
          url: 'https://bothunter.app',
        },
      }
    );

    // Add some example entries for testing
    this.registerCode(
      'baseapp',
      '0x1111111111111111111111111111111111111111',
      {
        app: {
          name: 'Base App',
          url: 'https://base.app',
        },
      }
    );

    this.registerCode(
      'morpho',
      '0x2222222222222222222222222222222222222222',
      {
        app: {
          name: 'Morpho',
          url: 'https://morpho.org',
        },
      }
    );

    this.registerCode(
      'coinbase',
      '0x3333333333333333333333333333333333333333',
      {
        app: {
          name: 'Coinbase Wallet',
          url: 'https://wallet.coinbase.com',
        },
      }
    );
  }

  /**
   * Register a new code (for testing only - not part of standard interface)
   * 
   * @param code Attribution code
   * @param payoutAddress Address to receive rewards
   * @param metadata App metadata
   */
  registerCode(code: string, payoutAddress: string, metadata: CodeMetadata): void {
    if (!this.isValidCodeSync(code)) {
      throw new Error(`Invalid code format: ${code}`);
    }

    if (!payoutAddress.match(/^0x[0-9a-fA-F]{40}$/)) {
      throw new Error(`Invalid payout address: ${payoutAddress}`);
    }

    this.registry.set(code.toLowerCase(), {
      code,
      payoutAddress,
      metadata,
      registered: true,
    });
  }

  /**
   * Unregister a code (for testing only)
   */
  unregisterCode(code: string): void {
    this.registry.delete(code.toLowerCase());
  }

  /**
   * Clear all registrations (for testing only)
   */
  clearRegistry(): void {
    this.registry.clear();
  }

  /**
   * Get all registered codes (for testing only)
   */
  getAllCodes(): string[] {
    return Array.from(this.registry.keys());
  }

  /**
   * ICodeRegistry interface implementation
   */

  async payoutAddress(code: string): Promise<string> {
    const entry = this.registry.get(code.toLowerCase());
    
    if (!entry || !entry.registered) {
      throw new Error(`Code not registered: ${code}`);
    }

    return entry.payoutAddress;
  }

  async codeURI(code: string): Promise<string> {
    const entry = this.registry.get(code.toLowerCase());
    
    if (!entry || !entry.registered) {
      throw new Error(`Code not registered: ${code}`);
    }

    // Return a mock metadata URI
    return `https://registry.base.org/metadata/${code}.json`;
  }

  async isValidCode(code: string): Promise<boolean> {
    return this.isValidCodeSync(code);
  }

  async isRegistered(code: string): Promise<boolean> {
    const entry = this.registry.get(code.toLowerCase());
    return entry?.registered || false;
  }

  /**
   * Synchronous validation helper
   */
  private isValidCodeSync(code: string): boolean {
    // Empty check
    if (!code || code.length === 0) {
      return false;
    }

    // Comma check (reserved delimiter)
    if (code.includes(',')) {
      return false;
    }

    // 7-bit ASCII check
    for (let i = 0; i < code.length; i++) {
      const charCode = code.charCodeAt(i);
      if (charCode > 127) {
        return false;
      }
    }

    // Length check (reasonable maximum)
    if (code.length > 50) {
      return false;
    }

    return true;
  }

  /**
   * Get metadata for a code (helper for testing)
   */
  async getMetadata(code: string): Promise<CodeMetadata> {
    const entry = this.registry.get(code.toLowerCase());
    
    if (!entry || !entry.registered) {
      throw new Error(`Code not registered: ${code}`);
    }

    return entry.metadata;
  }

  /**
   * Simulate querying multiple codes at once (batch operation)
   */
  async batchPayoutAddresses(codes: string[]): Promise<Record<string, string>> {
    const result: Record<string, string> = {};

    for (const code of codes) {
      try {
        result[code] = await this.payoutAddress(code);
      } catch (error) {
        // Code not found, skip
        continue;
      }
    }

    return result;
  }

  /**
   * Get registry statistics (for testing/monitoring)
   */
  getStats(): {
    totalCodes: number;
    registeredCodes: number;
    codes: string[];
  } {
    const allEntries = Array.from(this.registry.values());
    const registered = allEntries.filter(e => e.registered);

    return {
      totalCodes: this.registry.size,
      registeredCodes: registered.length,
      codes: registered.map(e => e.code),
    };
  }
}

/**
 * Global singleton instance for convenience
 */
export const mockRegistry = new MockCodeRegistry();

/**
 * Helper to get payout address for a code with fallback
 */
export async function getPayoutAddressOrDefault(
  code: string,
  defaultAddress: string
): Promise<string> {
  try {
    return await mockRegistry.payoutAddress(code);
  } catch (error) {
    console.warn(`Code ${code} not registered, using default address`);
    return defaultAddress;
  }
}

/**
 * Verify a code is registered and get its data
 */
export async function verifyAndGetCode(code: string): Promise<{
  registered: boolean;
  payoutAddress?: string;
  metadata?: CodeMetadata;
  error?: string;
}> {
  try {
    const isReg = await mockRegistry.isRegistered(code);
    
    if (!isReg) {
      return { registered: false, error: 'Code not registered' };
    }

    const payoutAddress = await mockRegistry.payoutAddress(code);
    const metadata = await mockRegistry.getMetadata(code);

    return {
      registered: true,
      payoutAddress,
      metadata,
    };
  } catch (error) {
    return {
      registered: false,
      error: (error as Error).message,
    };
  }
}
