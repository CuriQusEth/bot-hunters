/**
 * ERC-8021 Security Utilities
 * 
 * Security validation and sanitization functions for safe attribution handling
 * Implements security considerations from the ERC-8021 specification
 */

import { isValidCode, parseAttribution, ERC_SUFFIX } from './erc8021';
import type { AttributionConfig, ParsedAttribution } from '@/types/erc8021';

/**
 * Security validation result
 */
export interface ValidationResult {
  valid: boolean;
  errors: string[];
  warnings: string[];
}

/**
 * Validates attribution config for security issues
 * 
 * @param config Attribution configuration to validate
 * @returns Validation result with errors and warnings
 */
export function validateAttributionConfig(config: AttributionConfig): ValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  // Check codes array
  if (!config.codes || config.codes.length === 0) {
    errors.push('Codes array is empty or missing');
  }

  // Validate each code
  config.codes.forEach((code, index) => {
    if (!isValidCode(code)) {
      errors.push(`Code at index ${index} is invalid: "${code}"`);
    }

    // Check for potentially sensitive information
    if (code.toLowerCase().includes('user') || code.toLowerCase().includes('id')) {
      warnings.push(`Code "${code}" may contain identifying information`);
    }

    // Check for reasonable length
    if (code.length > 50) {
      warnings.push(`Code "${code}" is unusually long (${code.length} chars)`);
    }
  });

  // Schema 1 specific checks
  if (config.schemaId === 1) {
    if (!config.codeRegistryAddress) {
      errors.push('Registry address is required for Schema 1');
    } else if (!config.codeRegistryAddress.match(/^0x[0-9a-fA-F]{40}$/)) {
      errors.push('Registry address format is invalid');
    }

    if (!config.codeRegistryChainId) {
      errors.push('Chain ID is required for Schema 1');
    } else if (config.codeRegistryChainId < 1) {
      errors.push('Chain ID must be positive');
    }
  }

  return {
    valid: errors.length === 0,
    errors,
    warnings,
  };
}

/**
 * Safely parses attribution with comprehensive error handling
 * 
 * @param calldata Transaction calldata
 * @returns Parsed attribution or null with error info
 */
export function safeParseAttribution(
  calldata: string
): { result: ParsedAttribution | null; error?: string } {
  try {
    // Input validation
    if (!calldata || typeof calldata !== 'string') {
      return { result: null, error: 'Invalid calldata: must be non-empty string' };
    }

    // Normalize input
    const normalizedCalldata = calldata.startsWith('0x') ? calldata : `0x${calldata}`;

    // Minimum length check (prevents buffer underflow)
    if (normalizedCalldata.length < 38) { // "0x" + 36 chars minimum
      return { result: null, error: 'Calldata too short for attribution data' };
    }

    // Verify it contains ERC suffix
    const data = normalizedCalldata.slice(2);
    const ercSuffix = `0x${data.slice(-32)}`;
    
    if (ercSuffix.toLowerCase() !== ERC_SUFFIX.toLowerCase()) {
      return { result: null, error: 'No valid ERC-8021 suffix found' };
    }

    // Parse attribution
    const result = parseAttribution(normalizedCalldata);

    if (!result) {
      return { result: null, error: 'Failed to parse attribution data' };
    }

    // Validate parsed data
    if (result.codes.length === 0) {
      return { result: null, error: 'Parsed attribution has no codes' };
    }

    // Validate each parsed code
    for (const code of result.codes) {
      if (!isValidCode(code)) {
        return { result: null, error: `Invalid code in parsed data: "${code}"` };
      }
    }

    return { result };
  } catch (error) {
    return {
      result: null,
      error: `Parse error: ${(error as Error).message}`,
    };
  }
}

/**
 * Validates registry address security
 * 
 * @param address Registry contract address
 * @returns Validation result
 */
export function validateRegistryAddress(address: string): ValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  // Format check
  if (!address.match(/^0x[0-9a-fA-F]{40}$/)) {
    errors.push('Invalid address format');
    return { valid: false, errors, warnings };
  }

  // Check for zero address
  if (address.toLowerCase() === '0x0000000000000000000000000000000000000000') {
    errors.push('Registry address cannot be zero address');
  }

  // Warn about non-checksummed addresses
  const hasUppercase = /[A-F]/.test(address.slice(2));
  const hasLowercase = /[a-f]/.test(address.slice(2));
  
  if (hasUppercase && hasLowercase) {
    // Likely checksummed, good
  } else if (!hasUppercase && hasLowercase) {
    warnings.push('Address is not checksummed - verify it is correct');
  }

  return {
    valid: errors.length === 0,
    errors,
    warnings,
  };
}

/**
 * Checks if calldata has been potentially tampered with
 * Note: This is a basic check. For cryptographic proof, use signature-based verification
 * 
 * @param originalCalldata Original transaction calldata
 * @param receivedCalldata Received transaction calldata
 * @returns True if data appears intact
 */
export function verifyDataIntegrity(
  originalCalldata: string,
  receivedCalldata: string
): boolean {
  // Normalize inputs
  const normalizeHex = (hex: string) => {
    const clean = hex.toLowerCase().replace(/^0x/, '');
    return `0x${clean}`;
  };

  const original = normalizeHex(originalCalldata);
  const received = normalizeHex(receivedCalldata);

  // For basic integrity, the received should start with original
  // (attribution data is appended, not prepended)
  return received.startsWith(original.slice(2)) || received === original;
}

/**
 * Sanitizes attribution codes to prevent injection attacks
 * 
 * @param code Attribution code to sanitize
 * @returns Sanitized code or null if cannot be sanitized
 */
export function sanitizeCode(code: string): string | null {
  // Remove any non-ASCII characters
  const sanitized = code.replace(/[^\x00-\x7F]/g, '');

  // Remove commas (reserved delimiter)
  const noCommas = sanitized.replace(/,/g, '');

  // Check if sanitization changed the code significantly
  if (noCommas.length < code.length * 0.5) {
    return null; // Too much was removed
  }

  // Validate final result
  if (!isValidCode(noCommas)) {
    return null;
  }

  return noCommas;
}

/**
 * Rate limiting helper for attribution operations
 * Prevents DOS attacks from malicious attribution data
 */
export class AttributionRateLimiter {
  private attempts: Map<string, number[]> = new Map();
  private readonly maxAttempts: number;
  private readonly windowMs: number;

  constructor(maxAttempts: number = 10, windowMs: number = 60000) {
    this.maxAttempts = maxAttempts;
    this.windowMs = windowMs;
  }

  /**
   * Check if operation is allowed
   * 
   * @param identifier Unique identifier (e.g., user address, IP)
   * @returns True if allowed, false if rate limited
   */
  isAllowed(identifier: string): boolean {
    const now = Date.now();
    const attempts = this.attempts.get(identifier) || [];

    // Filter out old attempts outside the window
    const recentAttempts = attempts.filter(time => now - time < this.windowMs);

    // Check if under limit
    if (recentAttempts.length >= this.maxAttempts) {
      return false;
    }

    // Record this attempt
    recentAttempts.push(now);
    this.attempts.set(identifier, recentAttempts);

    return true;
  }

  /**
   * Reset rate limit for identifier
   */
  reset(identifier: string): void {
    this.attempts.delete(identifier);
  }

  /**
   * Clear all rate limits
   */
  clearAll(): void {
    this.attempts.clear();
  }
}

/**
 * Privacy checker - warns about potentially identifying information
 * 
 * @param config Attribution configuration
 * @returns Privacy warnings
 */
export function checkPrivacyCompliance(config: AttributionConfig): string[] {
  const warnings: string[] = [];

  config.codes.forEach(code => {
    // Check for common PII patterns
    const piiPatterns = [
      { pattern: /user/i, message: 'Code contains "user"' },
      { pattern: /id\d/i, message: 'Code contains ID-like pattern' },
      { pattern: /address/i, message: 'Code contains "address"' },
      { pattern: /wallet/i, message: 'Code contains "wallet"' },
      { pattern: /\d{4,}/, message: 'Code contains numeric sequence' },
    ];

    piiPatterns.forEach(({ pattern, message }) => {
      if (pattern.test(code)) {
        warnings.push(`Privacy: ${message} in code "${code}"`);
      }
    });
  });

  return warnings;
}

/**
 * Complete security audit for attribution data
 * 
 * @param config Attribution configuration
 * @returns Comprehensive validation result
 */
export function auditAttributionSecurity(config: AttributionConfig): ValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  // Config validation
  const configValidation = validateAttributionConfig(config);
  errors.push(...configValidation.errors);
  warnings.push(...configValidation.warnings);

  // Registry validation (Schema 1 only)
  if (config.schemaId === 1) {
    const registryValidation = validateRegistryAddress(config.codeRegistryAddress);
    errors.push(...registryValidation.errors);
    warnings.push(...registryValidation.warnings);
  }

  // Privacy compliance
  const privacyWarnings = checkPrivacyCompliance(config);
  warnings.push(...privacyWarnings);

  return {
    valid: errors.length === 0,
    errors,
    warnings,
  };
}
