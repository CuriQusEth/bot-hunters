/**
 * ERC-8021 Transaction Attribution Test Cases
 * 
 * Comprehensive test suite covering all specification requirements
 * including validation, parsing, security, and backward compatibility
 */

import {
  encodeSchema0,
  encodeSchema1,
  parseAttribution,
  isValidCode,
  areValidCodes,
  appendAttribution,
  ERC_SUFFIX,
} from './erc8021';
import type { ParsedAttribution } from '@/types/erc8021';

/**
 * Test Result Structure
 */
export interface TestResult {
  name: string;
  passed: boolean;
  error?: string;
  expected?: unknown;
  actual?: unknown;
}

/**
 * Test Suite Runner
 */
export class ERC8021TestSuite {
  private results: TestResult[] = [];

  /**
   * Run all test cases
   */
  runAll(): TestResult[] {
    this.results = [];
    
    // Validation tests
    this.testCodeValidation();
    
    // Encoding tests
    this.testSchema0Encoding();
    this.testSchema1Encoding();
    
    // Parsing tests (from spec)
    this.testSingleEntityParsing();
    this.testMultiEntityParsing();
    this.testInvalidSchemaIdHandling();
    
    // Security tests
    this.testMalformedDataHandling();
    this.testEmptyCodeRejection();
    this.testCommaInCodeRejection();
    this.testNonASCIIRejection();
    
    // Edge cases
    this.testMaxLengthCodes();
    this.testBackwardCompatibility();
    
    return this.results;
  }

  /**
   * Get summary of test results
   */
  getSummary(): { total: number; passed: number; failed: number } {
    const total = this.results.length;
    const passed = this.results.filter(r => r.passed).length;
    const failed = total - passed;
    
    return { total, passed, failed };
  }

  /**
   * Print test results
   */
  printResults(): void {
    console.log('\n=== ERC-8021 Test Results ===\n');
    
    this.results.forEach((result, index) => {
      const status = result.passed ? '✓' : '✗';
      console.log(`${status} Test ${index + 1}: ${result.name}`);
      
      if (!result.passed) {
        console.log(`  Error: ${result.error}`);
        if (result.expected !== undefined) {
          console.log(`  Expected: ${JSON.stringify(result.expected)}`);
          console.log(`  Actual: ${JSON.stringify(result.actual)}`);
        }
      }
    });
    
    const summary = this.getSummary();
    console.log(`\n=== Summary: ${summary.passed}/${summary.total} tests passed ===\n`);
  }

  /**
   * Helper to add test result
   */
  private addResult(name: string, passed: boolean, error?: string, expected?: unknown, actual?: unknown): void {
    this.results.push({ name, passed, error, expected, actual });
  }

  /**
   * Test code validation
   */
  private testCodeValidation(): void {
    // Valid codes
    this.addResult(
      'Valid code: "baseapp"',
      isValidCode('baseapp')
    );

    this.addResult(
      'Valid code: "bothunter"',
      isValidCode('bothunter')
    );

    // Invalid codes
    this.addResult(
      'Empty code should be invalid',
      !isValidCode('')
    );

    this.addResult(
      'Code with comma should be invalid',
      !isValidCode('base,app')
    );

    this.addResult(
      'Non-ASCII code should be invalid',
      !isValidCode('base™')
    );

    this.addResult(
      'Multiple valid codes',
      areValidCodes(['baseapp', 'morpho', 'bothunter'])
    );

    this.addResult(
      'Multiple codes with one invalid',
      !areValidCodes(['baseapp', 'invalid,code'])
    );
  }

  /**
   * Test Schema 0 encoding
   */
  private testSchema0Encoding(): void {
    try {
      const encoded = encodeSchema0(['baseapp']);
      const expected = '62617365617070070080218021802180218021802180218021';
      
      this.addResult(
        'Schema 0 single entity encoding',
        encoded === expected,
        encoded !== expected ? 'Encoding mismatch' : undefined,
        expected,
        encoded
      );
    } catch (error) {
      this.addResult(
        'Schema 0 single entity encoding',
        false,
        (error as Error).message
      );
    }

    try {
      const encoded = encodeSchema0(['baseapp', 'morpho']);
      const codesString = 'baseapp,morpho';
      const expectedLength = codesString.length.toString(16).padStart(2, '0');
      
      // Check if length byte is correct (14 = 0x0e)
      this.addResult(
        'Schema 0 multi-entity encoding length',
        encoded.includes(expectedLength),
        `Expected length ${expectedLength} not found in encoding`
      );
    } catch (error) {
      this.addResult(
        'Schema 0 multi-entity encoding',
        false,
        (error as Error).message
      );
    }
  }

  /**
   * Test Schema 1 encoding
   */
  private testSchema1Encoding(): void {
    try {
      const registryAddress = '0xcccccccccccccccccccccccccccccccccccccccc';
      const chainId = 8453;
      const encoded = encodeSchema1(['baseapp', 'morpho'], chainId, registryAddress);
      
      // Verify registry address is in the encoding
      this.addResult(
        'Schema 1 encoding includes registry address',
        encoded.includes(registryAddress.slice(2)),
        'Registry address not found in encoding'
      );

      // Verify schema ID is 1
      this.addResult(
        'Schema 1 encoding has correct schema ID',
        encoded.slice(-34, -32) === '01',
        'Schema ID should be 01'
      );
    } catch (error) {
      this.addResult(
        'Schema 1 encoding',
        false,
        (error as Error).message
      );
    }
  }

  /**
   * Test Case 1: Single entity attribution with canonical registry
   * Input: 0xdddddddd62617365617070070080218021802180218021802180218021
   */
  private testSingleEntityParsing(): void {
    const input = '0xdddddddd62617365617070070080218021802180218021802180218021';
    
    try {
      const parsed = parseAttribution(input);
      
      const expectedCodes = ['baseapp'];
      const expectedSchemaId = 0;
      
      const passed = 
        parsed !== null &&
        parsed.schemaId === expectedSchemaId &&
        JSON.stringify(parsed.codes) === JSON.stringify(expectedCodes);
      
      this.addResult(
        'Spec Test 1: Single entity + canonical registry',
        passed,
        passed ? undefined : 'Parsing failed or data mismatch',
        { schemaId: expectedSchemaId, codes: expectedCodes },
        parsed
      );
    } catch (error) {
      this.addResult(
        'Spec Test 1: Single entity + canonical registry',
        false,
        (error as Error).message
      );
    }
  }

  /**
   * Test Case 2: Multiple entity attribution with custom registry
   * Input: 0xddddddddcccccccccccccccccccccccccccccccccccccccc210502626173656170702c6d6f7270686f0e0180218021802180218021802180218021
   */
  private testMultiEntityParsing(): void {
    const input = '0xddddddddcccccccccccccccccccccccccccccccccccccccc210502626173656170702c6d6f7270686f0e0180218021802180218021802180218021';
    
    try {
      const parsed = parseAttribution(input);
      
      const expectedCodes = ['baseapp', 'morpho'];
      const expectedSchemaId = 1;
      const expectedChainId = 8453; // 0x2105
      const expectedRegistry = '0xcccccccccccccccccccccccccccccccccccccccc';
      
      const passed = 
        parsed !== null &&
        parsed.schemaId === expectedSchemaId &&
        JSON.stringify(parsed.codes) === JSON.stringify(expectedCodes) &&
        parsed.codeRegistryChainId === expectedChainId &&
        parsed.codeRegistryAddress?.toLowerCase() === expectedRegistry.toLowerCase();
      
      this.addResult(
        'Spec Test 2: Multi-entity + custom registry',
        passed,
        passed ? undefined : 'Parsing failed or data mismatch',
        { 
          schemaId: expectedSchemaId, 
          codes: expectedCodes,
          codeRegistryChainId: expectedChainId,
          codeRegistryAddress: expectedRegistry
        },
        parsed
      );
    } catch (error) {
      this.addResult(
        'Spec Test 2: Multi-entity + custom registry',
        false,
        (error as Error).message
      );
    }
  }

  /**
   * Test Case 3: Invalid schema ID handling
   * Input: 0xddddddddff80218021802180218021802180218021
   */
  private testInvalidSchemaIdHandling(): void {
    const input = '0xddddddddff80218021802180218021802180218021';
    
    try {
      const parsed = parseAttribution(input);
      
      // Should return null for unknown schema ID
      this.addResult(
        'Spec Test 3: Invalid schema ID handling',
        parsed === null,
        parsed === null ? undefined : 'Should return null for unknown schema ID',
        null,
        parsed
      );
    } catch (error) {
      this.addResult(
        'Spec Test 3: Invalid schema ID handling',
        false,
        (error as Error).message
      );
    }
  }

  /**
   * Test malformed data handling (security)
   */
  private testMalformedDataHandling(): void {
    // Too short data
    const tooShort = '0x123456';
    this.addResult(
      'Security: Reject too short data',
      parseAttribution(tooShort) === null
    );

    // Invalid ERC suffix
    const invalidSuffix = '0xdddddddd626173656170700700ffffffffffffffffffffffffffffffff';
    this.addResult(
      'Security: Reject invalid ERC suffix',
      parseAttribution(invalidSuffix) === null
    );

    // Corrupted length byte
    const corruptedLength = '0xdddddddd62617365617070ff0080218021802180218021802180218021';
    this.addResult(
      'Security: Handle corrupted length gracefully',
      parseAttribution(corruptedLength) === null
    );
  }

  /**
   * Test empty code rejection
   */
  private testEmptyCodeRejection(): void {
    try {
      encodeSchema0(['']);
      this.addResult(
        'Security: Reject empty code in encoding',
        false,
        'Should throw error for empty code'
      );
    } catch (error) {
      this.addResult(
        'Security: Reject empty code in encoding',
        true
      );
    }
  }

  /**
   * Test comma in code rejection
   */
  private testCommaInCodeRejection(): void {
    try {
      encodeSchema0(['base,app']);
      this.addResult(
        'Security: Reject comma in code',
        false,
        'Should throw error for comma in code'
      );
    } catch (error) {
      this.addResult(
        'Security: Reject comma in code',
        true
      );
    }
  }

  /**
   * Test non-ASCII code rejection
   */
  private testNonASCIIRejection(): void {
    try {
      encodeSchema0(['baseapp™']);
      this.addResult(
        'Security: Reject non-ASCII characters',
        false,
        'Should throw error for non-ASCII characters'
      );
    } catch (error) {
      this.addResult(
        'Security: Reject non-ASCII characters',
        true
      );
    }
  }

  /**
   * Test maximum length codes
   */
  private testMaxLengthCodes(): void {
    // Test with 255 bytes (maximum)
    const maxCode = 'a'.repeat(255);
    try {
      const encoded = encodeSchema0([maxCode]);
      this.addResult(
        'Edge case: Maximum length code (255 bytes)',
        encoded.length > 0
      );
    } catch (error) {
      this.addResult(
        'Edge case: Maximum length code (255 bytes)',
        false,
        (error as Error).message
      );
    }

    // Test with 256 bytes (should fail)
    const tooLongCode = 'a'.repeat(256);
    try {
      encodeSchema0([tooLongCode]);
      this.addResult(
        'Edge case: Reject code exceeding 255 bytes',
        false,
        'Should throw error for code exceeding 255 bytes'
      );
    } catch (error) {
      this.addResult(
        'Edge case: Reject code exceeding 255 bytes',
        true
      );
    }
  }

  /**
   * Test backward compatibility
   */
  private testBackwardCompatibility(): void {
    // Transaction without attribution should parse normally
    const normalTx = '0xdddddddd1234567890abcdef';
    this.addResult(
      'Backward compatibility: Normal tx without attribution',
      parseAttribution(normalTx) === null,
      'Non-attributed tx should return null'
    );

    // Transaction with attribution should not affect execution
    const txData = '0xdddddddd';
    const attributed = appendAttribution(txData, {
      schemaId: 0,
      codes: ['bothunter']
    });
    
    this.addResult(
      'Backward compatibility: Attribution does not affect tx data',
      attributed.startsWith(txData),
      'Original tx data should be preserved at start'
    );
  }
}

/**
 * Run all tests and return results
 */
export function runERC8021Tests(): TestResult[] {
  const suite = new ERC8021TestSuite();
  const results = suite.runAll();
  suite.printResults();
  return results;
}

/**
 * Quick validation check for production use
 */
export function validateERC8021Implementation(): boolean {
  const suite = new ERC8021TestSuite();
  const results = suite.runAll();
  const summary = suite.getSummary();
  
  return summary.failed === 0;
}
