/**
 * ERC-8021 Transaction Attribution Utilities
 * 
 * Provides functions for encoding and parsing ERC-8021 attribution data suffixes
 * that can be appended to transaction calldata.
 * 
 * @see https://ethereum-magicians.org/t/erc-8021-transaction-attribution/25561
 */

import type { AttributionConfig, ParsedAttribution, SchemaId } from '@/types/erc8021';

/**
 * ERC-8021 suffix identifier ("8021" repeated)
 * This 16-byte value indicates use of this standard
 */
export const ERC_SUFFIX = '0x80218021802180218021802180218021';

/**
 * Validates an attribution code format
 * - Must follow 7-bit ASCII encoding
 * - Must NOT contain commas (0x2C)
 * - Must NOT be empty
 * 
 * @param code The attribution code to validate
 * @returns True if valid, false otherwise
 */
export function isValidCode(code: string): boolean {
  if (!code || code.length === 0) {
    return false;
  }

  // Check for commas (reserved as delimiter)
  if (code.includes(',')) {
    return false;
  }

  // Check 7-bit ASCII (0x00 - 0x7F)
  for (let i = 0; i < code.length; i++) {
    const charCode = code.charCodeAt(i);
    if (charCode > 127) {
      return false;
    }
  }

  return true;
}

/**
 * Validates multiple attribution codes
 * 
 * @param codes Array of attribution codes to validate
 * @returns True if all codes are valid, false otherwise
 */
export function areValidCodes(codes: string[]): boolean {
  return codes.every(isValidCode);
}

/**
 * Encodes attribution codes into Schema 0 format
 * Uses chain's canonical Code Registry
 * 
 * Format: {codes}{codesLength}{schemaId}{ercSuffix}
 * 
 * @param codes Array of attribution codes
 * @returns Hex-encoded suffix to append to calldata
 */
export function encodeSchema0(codes: string[]): string {
  if (!areValidCodes(codes)) {
    throw new Error('Invalid attribution codes: must be 7-bit ASCII without commas');
  }

  // Join codes with comma delimiter
  const codesString = codes.join(',');
  const codesBytes = stringToHex(codesString);
  const codesLength = codesString.length;

  if (codesLength > 255) {
    throw new Error('Total codes length exceeds 255 bytes');
  }

  // Build suffix: codes + codesLength + schemaId + ercSuffix
  const codesLengthHex = numberToHex(codesLength, 1);
  const schemaIdHex = '0x00';

  return `${codesBytes}${codesLengthHex.slice(2)}${schemaIdHex.slice(2)}${ERC_SUFFIX.slice(2)}`;
}

/**
 * Encodes attribution codes into Schema 1 format
 * Uses custom Code Registry on specified chain
 * 
 * Format: {codes}{codesLength}{chainId}{chainIdLength}{registryAddress}{schemaId}{ercSuffix}
 * 
 * @param codes Array of attribution codes
 * @param chainId Chain ID hosting the custom Code Registry
 * @param registryAddress Address of the Code Registry contract
 * @returns Hex-encoded suffix to append to calldata
 */
export function encodeSchema1(
  codes: string[],
  chainId: number,
  registryAddress: string
): string {
  if (!areValidCodes(codes)) {
    throw new Error('Invalid attribution codes: must be 7-bit ASCII without commas');
  }

  if (!registryAddress.match(/^0x[0-9a-fA-F]{40}$/)) {
    throw new Error('Invalid registry address format');
  }

  // Join codes with comma delimiter
  const codesString = codes.join(',');
  const codesBytes = stringToHex(codesString);
  const codesLength = codesString.length;

  if (codesLength > 255) {
    throw new Error('Total codes length exceeds 255 bytes');
  }

  // Encode chain ID (variable length)
  const chainIdHex = numberToHex(chainId);
  const chainIdLength = (chainIdHex.length - 2) / 2; // Remove '0x' and convert to byte length

  if (chainIdLength > 255) {
    throw new Error('Chain ID length exceeds 255 bytes');
  }

  // Build suffix
  const codesLengthHex = numberToHex(codesLength, 1);
  const chainIdLengthHex = numberToHex(chainIdLength, 1);
  const schemaIdHex = '0x01';

  return (
    `${codesBytes}${codesLengthHex.slice(2)}` +
    `${chainIdHex.slice(2)}${chainIdLengthHex.slice(2)}` +
    `${registryAddress.slice(2)}` +
    `${schemaIdHex.slice(2)}${ERC_SUFFIX.slice(2)}`
  );
}

/**
 * Encodes attribution config into appropriate schema format
 * 
 * @param config Attribution configuration (Schema 0 or 1)
 * @returns Hex-encoded suffix to append to calldata
 */
export function encodeAttribution(config: AttributionConfig): string {
  if (config.schemaId === 0) {
    return encodeSchema0(config.codes);
  } else if (config.schemaId === 1) {
    return encodeSchema1(
      config.codes,
      config.codeRegistryChainId,
      config.codeRegistryAddress
    );
  }

  throw new Error(`Unsupported schema ID: ${config.schemaId}`);
}

/**
 * Appends ERC-8021 attribution suffix to transaction calldata
 * 
 * @param calldata Original transaction calldata (hex string)
 * @param config Attribution configuration
 * @returns Calldata with attribution suffix appended
 */
export function appendAttribution(calldata: string, config: AttributionConfig): string {
  const suffix = encodeAttribution(config);
  
  // Ensure calldata starts with '0x'
  const normalizedCalldata = calldata.startsWith('0x') ? calldata : `0x${calldata}`;
  
  return `${normalizedCalldata}${suffix.slice(2)}`;
}

/**
 * Parses ERC-8021 attribution data from transaction calldata
 * 
 * @param calldata Transaction calldata with attribution suffix
 * @returns Parsed attribution data, or null if no valid attribution found
 */
export function parseAttribution(calldata: string): ParsedAttribution | null {
  try {
    // Remove '0x' prefix if present
    const data = calldata.startsWith('0x') ? calldata.slice(2) : calldata;

    // Check minimum length (16 bytes ercSuffix + 1 byte schemaId + 1 byte codesLength)
    if (data.length < 36) {
      return null;
    }

    // Extract and verify ercSuffix (last 16 bytes = 32 hex chars)
    const ercSuffix = `0x${data.slice(-32)}`;
    if (ercSuffix.toLowerCase() !== ERC_SUFFIX.toLowerCase()) {
      return null;
    }

    // Extract schemaId (1 byte before ercSuffix = 2 hex chars)
    const schemaIdHex = data.slice(-34, -32);
    const schemaId = parseInt(schemaIdHex, 16) as SchemaId;

    if (schemaId === 0) {
      return parseSchema0(data);
    } else if (schemaId === 1) {
      return parseSchema1(data);
    }

    // Unknown schema ID
    return null;
  } catch (error) {
    console.error('Error parsing attribution:', error);
    return null;
  }
}

/**
 * Parses Schema 0 attribution data
 */
function parseSchema0(data: string): ParsedAttribution {
  // Extract codesLength (1 byte before schemaId = 2 hex chars)
  const codesLengthHex = data.slice(-36, -34);
  const codesLength = parseInt(codesLengthHex, 16);

  // Extract codes (codesLength bytes before codesLength = codesLength * 2 hex chars)
  const codesStartIndex = -36 - codesLength * 2;
  const codesHex = data.slice(codesStartIndex, -36);
  const codesString = hexToString(`0x${codesHex}`);

  // Split codes by comma delimiter
  const codes = codesString.split(',');

  return {
    schemaId: 0,
    codes,
  };
}

/**
 * Parses Schema 1 attribution data
 */
function parseSchema1(data: string): ParsedAttribution {
  // Extract codesLength (1 byte before schemaId = 2 hex chars)
  const codesLengthHex = data.slice(-36, -34);
  const codesLength = parseInt(codesLengthHex, 16);

  // Extract codes
  const codesStartIndex = -36 - codesLength * 2;
  const codesHex = data.slice(codesStartIndex, -36);
  const codesString = hexToString(`0x${codesHex}`);
  const codes = codesString.split(',');

  // Extract chainIdLength (1 byte before codes)
  const chainIdLengthHex = data.slice(codesStartIndex - 2, codesStartIndex);
  const chainIdLength = parseInt(chainIdLengthHex, 16);

  // Extract chainId
  const chainIdStartIndex = codesStartIndex - 2 - chainIdLength * 2;
  const chainIdHex = data.slice(chainIdStartIndex, codesStartIndex - 2);
  const chainId = parseInt(chainIdHex, 16);

  // Extract registryAddress (20 bytes = 40 hex chars before chainId)
  const registryHex = data.slice(chainIdStartIndex - 40, chainIdStartIndex);
  const registryAddress = `0x${registryHex}`;

  return {
    schemaId: 1,
    codes,
    codeRegistryChainId: chainId,
    codeRegistryAddress: registryAddress,
  };
}

/**
 * Helper: Convert string to hex
 */
function stringToHex(str: string): string {
  let hex = '0x';
  for (let i = 0; i < str.length; i++) {
    const code = str.charCodeAt(i);
    hex += code.toString(16).padStart(2, '0');
  }
  return hex;
}

/**
 * Helper: Convert hex to string
 */
function hexToString(hex: string): string {
  const cleanHex = hex.startsWith('0x') ? hex.slice(2) : hex;
  let str = '';
  for (let i = 0; i < cleanHex.length; i += 2) {
    const code = parseInt(cleanHex.slice(i, i + 2), 16);
    str += String.fromCharCode(code);
  }
  return str;
}

/**
 * Helper: Convert number to hex with optional fixed byte length
 */
function numberToHex(num: number, byteLength?: number): string {
  const hex = num.toString(16);
  const paddedHex = byteLength ? hex.padStart(byteLength * 2, '0') : hex;
  return `0x${paddedHex}`;
}

/**
 * Creates a data suffix capability for ERC-5792 wallet_sendCalls
 * 
 * @param config Attribution configuration
 * @returns Data suffix capability object
 */
export function createDataSuffixCapability(config: AttributionConfig): { dataSuffix: string } {
  return {
    dataSuffix: encodeAttribution(config),
  };
}

/**
 * Alias for encodeSchema0 - convenience function for standard attribution
 * @alias encodeSchema0
 */
export const encodeSchema0Attribution = encodeSchema0;
