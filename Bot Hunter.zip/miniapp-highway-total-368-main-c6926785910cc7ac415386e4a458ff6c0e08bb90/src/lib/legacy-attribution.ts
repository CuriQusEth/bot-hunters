/**
 * Legacy Attribution Utilities
 * 
 * For backward compatibility with writeContract and other legacy patterns
 * Manually appends attribution suffix to calldata (EOA transactions only)
 * 
 * ⚠️ IMPORTANT: These functions DO NOT support Smart Accounts (ERC-4337)
 * Use useAttributedTransaction hook for modern wallet_sendCalls instead
 */

import { encodeFunctionData } from 'viem';
import { addBotHunterAttribution } from './attribution';
import type { Abi, Address } from 'viem';

/**
 * Prepare legacy transaction with manual attribution
 * 
 * For use with writeContract or sendTransaction (EOA only)
 * 
 * @param abi Contract ABI
 * @param functionName Function name to call
 * @param args Function arguments
 * @returns Calldata with attribution suffix appended
 * 
 * @example
 * ```tsx
 * const data = prepareLegacyTransaction(
 *   NFT_ABI,
 *   'mint',
 *   [userAddress, tokenId]
 * );
 * 
 * await writeContract({
 *   address: contractAddress,
 *   abi: NFT_ABI,
 *   functionName: 'mint',
 *   args: [userAddress, tokenId],
 *   data: data // Use attributed calldata
 * });
 * ```
 */
export function prepareLegacyTransaction<TAbi extends Abi>(
  abi: TAbi,
  functionName: string,
  args: any[]
): `0x${string}` {
  // 1. Encode function call
  const encoded = encodeFunctionData({
    abi,
    functionName,
    args,
  });

  // 2. Manually append attribution suffix
  const dataWithSuffix = addBotHunterAttribution(encoded);

  return dataWithSuffix as `0x${string}`;
}

/**
 * Prepare simple ETH transfer with attribution
 * 
 * @param to Recipient address
 * @param value Amount in wei
 * @returns Transaction object with attribution
 * 
 * @example
 * ```tsx
 * const tx = prepareLegacyEthTransfer(
 *   '0xRecipient',
 *   1000000000000000n // 0.001 ETH
 * );
 * 
 * await sendTransaction(tx);
 * ```
 */
export function prepareLegacyEthTransfer(
  to: Address,
  value: bigint
) {
  // For simple ETH transfers, attribution suffix is added to data field
  const emptyData = '0x';
  const dataWithSuffix = addBotHunterAttribution(emptyData);

  return {
    to,
    value,
    data: dataWithSuffix as `0x${string}`,
  };
}

/**
 * Manual attribution for custom calldata
 * 
 * Use when you already have encoded calldata
 * 
 * @param calldata Pre-encoded transaction calldata
 * @returns Calldata with attribution suffix
 * 
 * @example
 * ```tsx
 * const customCalldata = '0x...';
 * const attributed = addManualAttribution(customCalldata);
 * 
 * await sendTransaction({
 *   to: contractAddress,
 *   data: attributed
 * });
 * ```
 */
export function addManualAttribution(calldata: `0x${string}`): `0x${string}` {
  return addBotHunterAttribution(calldata) as `0x${string}`;
}

/**
 * Batch prepare multiple legacy transactions
 * 
 * @param transactions Array of transaction configs
 * @returns Array of transactions with attribution
 */
export function prepareLegacyBatch(
  transactions: Array<{
    abi: Abi;
    functionName: string;
    args: any[];
  }>
) {
  return transactions.map(({ abi, functionName, args }) => 
    prepareLegacyTransaction(abi, functionName, args)
  );
}

/**
 * Validation: Check if calldata already has attribution
 * 
 * @param calldata Transaction calldata
 * @returns True if attribution suffix is present
 */
export function hasAttribution(calldata: string): boolean {
  // Check for ERC-8021 suffix (0x8021... repeated)
  const ercSuffix = '80218021802180218021802180218021';
  return calldata.toLowerCase().endsWith(ercSuffix);
}

/**
 * Safe attribution: Only add if not already present
 * 
 * @param calldata Transaction calldata
 * @returns Calldata with attribution (if not already present)
 */
export function safeAddAttribution(calldata: `0x${string}`): `0x${string}` {
  if (hasAttribution(calldata)) {
    return calldata;
  }
  return addManualAttribution(calldata);
}
