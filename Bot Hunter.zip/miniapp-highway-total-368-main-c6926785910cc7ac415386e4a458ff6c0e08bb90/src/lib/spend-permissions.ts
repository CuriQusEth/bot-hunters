import type { SpendPermission, SpendPermissionStatus, SpendCallData } from '@/types/spend-permission'

/**
 * Base Spend Permissions Utilities
 * 
 * These utilities wrap the @base-org/account/spend-permission functions
 * for use in the Bot Hunter game. They enable seamless transactions for
 * rewards and in-game purchases without requiring signatures each time.
 */

// Dynamic imports to avoid SSR issues
let spendPermissionModule: typeof import('@base-org/account/spend-permission') | null = null

async function getSpendPermissionModule() {
  if (!spendPermissionModule) {
    spendPermissionModule = await import('@base-org/account/spend-permission')
  }
  return spendPermissionModule
}

/**
 * Request a spend permission from the user
 * 
 * @param params - Parameters for the spend permission request
 * @param provider - EIP-1193 provider (e.g., from wallet)
 * @returns The created spend permission with signature
 */
export async function requestSpendPermission(
  params: {
    account: `0x${string}`
    spender: `0x${string}`
    token: `0x${string}`
    chainId: number
    allowance: bigint
    periodInDays: number
  },
  provider: any
): Promise<SpendPermission> {
  try {
    const module = await getSpendPermissionModule()
    const permission = await module.requestSpendPermission({
      ...params,
      provider,
    })
    return permission as SpendPermission
  } catch (error) {
    console.error('Error requesting spend permission:', error)
    throw new Error('Failed to request spend permission')
  }
}

/**
 * Prepare call data for spending tokens using a permission
 * 
 * @param permission - The spend permission to use
 * @param amount - Amount to spend (optional, uses remaining allowance if not provided)
 * @returns Array of calls to execute (may include approval if first use)
 */
export async function prepareSpendCallData(
  permission: SpendPermission,
  amount?: bigint
): Promise<SpendCallData[]> {
  try {
    const module = await getSpendPermissionModule()
    const calls = await module.prepareSpendCallData({
      permission,
      amount,
    })
    return calls as SpendCallData[]
  } catch (error) {
    console.error('Error preparing spend call data:', error)
    throw new Error('Failed to prepare spend call data')
  }
}

/**
 * Get the status of a spend permission
 * 
 * @param permission - The spend permission to check
 * @returns Status information including whether it's active and remaining allowance
 */
export async function getPermissionStatus(
  permission: SpendPermission
): Promise<SpendPermissionStatus> {
  try {
    const module = await getSpendPermissionModule()
    const status = await module.getPermissionStatus(permission)
    return status as SpendPermissionStatus
  } catch (error) {
    console.error('Error getting permission status:', error)
    throw new Error('Failed to get permission status')
  }
}

/**
 * Fetch all spend permissions for an account
 * 
 * @param params - Parameters including account address and spender
 * @param provider - EIP-1193 provider
 * @returns Array of spend permissions
 */
export async function fetchPermissions(
  params: {
    account: `0x${string}`
    chainId: number
    spender: `0x${string}`
  },
  provider: any
): Promise<SpendPermission[]> {
  try {
    const module = await getSpendPermissionModule()
    const permissions = await module.fetchPermissions({
      ...params,
      provider,
    })
    return permissions as SpendPermission[]
  } catch (error) {
    console.error('Error fetching permissions:', error)
    return []
  }
}

/**
 * Fetch a specific spend permission by its hash
 * 
 * @param permissionHash - The hash of the permission to fetch
 * @param provider - EIP-1193 provider
 * @returns The spend permission
 */
export async function fetchPermission(
  permissionHash: `0x${string}`,
  provider: any
): Promise<SpendPermission | null> {
  try {
    const module = await getSpendPermissionModule()
    const permission = await module.fetchPermission({
      permissionHash,
      provider,
    })
    return permission as SpendPermission
  } catch (error) {
    console.error('Error fetching permission:', error)
    return null
  }
}

/**
 * Request user to revoke a spend permission
 * 
 * @param permission - The permission to revoke
 * @returns Transaction hash
 */
export async function requestRevoke(
  permission: SpendPermission
): Promise<`0x${string}`> {
  try {
    const module = await getSpendPermissionModule()
    const hash = await module.requestRevoke(permission)
    return hash as `0x${string}`
  } catch (error) {
    console.error('Error requesting revoke:', error)
    throw new Error('Failed to revoke permission')
  }
}

/**
 * Prepare call data for revoking a permission (spender-initiated)
 * 
 * @param permission - The permission to revoke
 * @returns Call data for the revoke transaction
 */
export async function prepareRevokeCallData(
  permission: SpendPermission
): Promise<SpendCallData> {
  try {
    const module = await getSpendPermissionModule()
    const call = await module.prepareRevokeCallData(permission)
    return call as SpendCallData
  } catch (error) {
    console.error('Error preparing revoke call data:', error)
    throw new Error('Failed to prepare revoke call data')
  }
}

/**
 * Execute spend calls using wallet_sendCalls or eth_sendTransaction
 * 
 * @param calls - Array of calls to execute
 * @param spender - Spender address
 * @param provider - EIP-1193 provider
 * @returns Transaction hash or batch ID
 */
export async function executeSpendCalls(
  calls: SpendCallData[],
  spender: `0x${string}`,
  provider: any
): Promise<string> {
  try {
    // Try wallet_sendCalls first (batched execution)
    try {
      const result = await provider.request({
        method: 'wallet_sendCalls',
        params: [
          {
            version: '2.0',
            atomicRequired: true,
            from: spender,
            calls,
          },
        ],
      })
      return result
    } catch {
      // Fallback to sequential eth_sendTransaction
      const hashes: string[] = []
      for (const call of calls) {
        const hash = await provider.request({
          method: 'eth_sendTransaction',
          params: [
            {
              ...call,
              from: spender,
            },
          ],
        })
        hashes.push(hash)
      }
      return hashes[hashes.length - 1] // Return last hash
    }
  } catch (error) {
    console.error('Error executing spend calls:', error)
    throw new Error('Failed to execute spend calls')
  }
}
