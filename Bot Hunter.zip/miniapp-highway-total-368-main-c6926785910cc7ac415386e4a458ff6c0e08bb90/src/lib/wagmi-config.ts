/**
 * Wagmi Configuration for Bot Hunter
 * 
 * Configures Web3 wallet connections and network settings
 * for Base mainnet and testnet
 */

import { createConfig, http } from 'wagmi';
import { base, baseSepolia } from 'wagmi/chains';
import { coinbaseWallet, injected, walletConnect } from 'wagmi/connectors';

/**
 * Wagmi configuration with Base networks
 * Supports Coinbase Wallet, MetaMask, and WalletConnect
 */
export const wagmiConfig = createConfig({
  chains: [base, baseSepolia],
  connectors: [
    coinbaseWallet({
      appName: 'Bot Hunter',
      appLogoUrl: 'https://bothunter.app/logo.png',
    }),
    injected({
      target: 'metaMask',
    }),
    walletConnect({
      projectId: process.env.NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID || 'demo',
    }),
  ],
  transports: {
    [base.id]: http(),
    [baseSepolia.id]: http(),
  },
});

/**
 * Network configuration exports
 */
export { base, baseSepolia };
