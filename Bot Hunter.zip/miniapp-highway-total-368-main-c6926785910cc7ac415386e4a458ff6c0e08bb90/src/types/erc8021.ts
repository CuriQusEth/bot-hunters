/**
 * ERC-8021 Transaction Attribution Types
 * 
 * A standardized method for attributing transactions to applications and wallets
 * through data suffixes, enabling interoperable attribution tracking and reward distribution.
 */

/**
 * Schema ID for ERC-8021 attribution
 * - 0: Single or multi-entity attribution with canonical registry
 * - 1: Multi-entity attribution with custom registry
 */
export type SchemaId = 0 | 1;

/**
 * Attribution code representing an entity (application, wallet, etc.)
 * Must follow 7-bit ASCII encoding and NOT contain commas (0x2C)
 */
export type AttributionCode = string;

/**
 * Code Registry interface for querying attribution metadata
 */
export interface ICodeRegistry {
  /**
   * Fetch a code's address to payout incentives
   * @param code The code to query
   * @returns The address to receive rewards for this code
   */
  payoutAddress(code: string): Promise<string>;

  /**
   * Fetch a code's URI to fetch for additional metadata
   * @param code The code to query
   * @returns The URI pointing to metadata about this code
   */
  codeURI(code: string): Promise<string>;

  /**
   * Check if a code is valid format (characters, length, etc)
   * @param code The code to query
   * @returns True if the code is valid, false otherwise
   */
  isValidCode(code: string): Promise<boolean>;

  /**
   * Check if a code is registered
   * @param code The code to query
   * @returns True if the code is registered, false otherwise
   */
  isRegistered(code: string): Promise<boolean>;
}

/**
 * Code metadata structure returned from codeURI
 */
export interface CodeMetadata {
  app: {
    name: string;
    url: string;
  };
}

/**
 * ERC-5792 Data Suffix Capability
 * Applications using wallet_sendCalls RPC method communicate attribution
 * through this capability
 */
export interface DataSuffixCapability {
  dataSuffix: string; // Hex-encoded bytes to append as suffix
}

/**
 * Configuration for Schema 0 attribution
 * Uses chain's canonical Code Registry
 */
export interface Schema0Config {
  schemaId: 0;
  codes: AttributionCode[];
}

/**
 * Configuration for Schema 1 attribution
 * Uses custom Code Registry on specified chain
 */
export interface Schema1Config {
  schemaId: 1;
  codes: AttributionCode[];
  codeRegistryChainId: number;
  codeRegistryAddress: string;
}

/**
 * Union type for attribution configuration
 */
export type AttributionConfig = Schema0Config | Schema1Config;

/**
 * Parsed ERC-8021 attribution data
 */
export interface ParsedAttribution {
  schemaId: SchemaId;
  codes: AttributionCode[];
  codeRegistryChainId?: number;
  codeRegistryAddress?: string;
}

/**
 * Canonical Code Registry addresses per chain
 */
export const CANONICAL_REGISTRIES: Record<number, string> = {
  8453: 'TBD', // Base Mainnet
  84532: 'TBD', // Base Sepolia
};
