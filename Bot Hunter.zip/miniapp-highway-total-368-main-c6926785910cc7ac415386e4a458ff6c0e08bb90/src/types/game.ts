export type GameState = 'start' | 'playing' | 'gameover'

export type CastType = 'bot' | 'real'

export interface Cast {
  id: string
  type: CastType
  username: string
  avatar: string
  content: string
  timestamp: number
  position: number
}

export interface GameStats {
  score: number
  combo: number
  botsDestroyed: number
  totalClicks: number
  correctClicks: number
  timeRemaining: number
}

export interface PowerUp {
  id: string
  type: 'rapidfire' | 'filter' | 'timeboost' | 'doublepoints'
  name: string
  icon: string
  duration: number
  active: boolean
}
