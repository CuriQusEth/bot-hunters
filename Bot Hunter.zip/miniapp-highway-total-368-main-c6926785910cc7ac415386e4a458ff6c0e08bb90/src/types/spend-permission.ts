export interface SpendPermission {
  account: `0x${string}`
  spender: `0x${string}`
  token: `0x${string}`
  allowance: bigint
  period: number
  start: number
  end: number
  salt: bigint
  extraData: `0x${string}`
  signature?: `0x${string}`
}

export interface SpendPermissionStatus {
  isActive: boolean
  remainingSpend: bigint
  nextResetTime?: number
}

export interface SpendPermissionRequest {
  account: `0x${string}`
  spender: `0x${string}`
  token: `0x${string}`
  chainId: number
  allowance: bigint
  periodInDays: number
}

export interface SpendCallData {
  to: `0x${string}`
  data: `0x${string}`
  value?: bigint
}

export interface SpendPermissionManagerProps {
  onPermissionGranted?: (permission: SpendPermission) => void
  onPermissionRevoked?: () => void
}
